# Installation

```bash
python setup.py develop
```
