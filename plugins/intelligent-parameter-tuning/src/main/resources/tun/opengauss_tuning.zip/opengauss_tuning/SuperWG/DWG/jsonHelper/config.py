# 调优配置
# 随机采样次数
sampling_number = 50
# 模型推荐次数
iteration = 100
# 调优方式, 在线True, 离线False
online = False
# 是否进行微调, iteration为微调次数
finetune = True
# 在线调优是否允许重启
restart_when_online = False
# 调优过程中是否备份数据库
#backup = False
backup = True
# 是否绑定核
taskset = True
# 如果绑核, 绑哪些核, 0即绑定到cpu0, 0-3即绑定在cpu0、1、3
# 数据库绑定核心
db_cpus = "4-15"
# 压测工具绑定核心
pt_cpus = "0-3"
# 数据库待调整的配置参数文件
knobs_file = 'knobs_config/knobs-13.json'
# 进行重要性排名后, 选取的配置参数的数量
ranked_knobs_number = 13
method = 'HEBO'
log_path = 'log'
final_results = 'final_results'
knowledge = 'knowledge.json'


# 数据库配置
host = '10.29.210.203'
port = 30100
db = 'dbtest'
#db = 'db_newsql_178'
user = 'dbuser'
password = 'openGauss@123'
omm_password = 'openGauss@123'
# 数据库数据目录
opengauss_node_path = '/data/gaussdb/cluster/data'
# 数据库数据备份路径
#backup_path = '/data/bak_gaussdb_data/dwg/data'
backup_path = '/data/bak_gaussdb_data/sys/data'
#root_password = '1234321'
# 重启数据库的等待时间, 若超时仍未启动, 则恢复数据库
time_wait = 300


# 所使用的压测工具 sysbench 或 dwg
#benchmark = 'sysbench'
benchmark = 'dwg'
# 压测线程数
threads = 128


# sysbench配置
tables = 20
table_size = 2000000
mode = 'oltp_read_write'
runing_time = 60
# 正式压测之前预热时间, 结果不计算在最终tps中
warm_up_time = 30


# dwg配置
# 需要解析的schema名称
#schema_name = 'db_newsql_movie'
schema_name = 'public'
# 执行gs_dump命令后在服务端保存的结果(建表语句等, 用于生成负载)
remote_cache_path = '/home/omm/test.sql'
# 执行gs_dump命令后在本地保存的结果
local_cache_path = 'workloads/schema/test.sql'
# 默认不分析本地文件
use_local = 'false'
# 生成负载的规模
sql_num = 10000
# 生成负载的读写比 read / total
read_write_ratio = 0.9
# 生成负载的其他配置信息
json_extract_result_path = 'workloads/schema/res.json'
# 生成负载的保存路径, 也是使用dwg压测所用的负载
#workload = 'workloads/res_cbg_simple_100.wg'
workload = 'workloads/res.wg'
# 每个线程成功执行sql_num_print条sql后在控制台输出信息

sql_num_print = 500
table_domain_distribution = [0.5, 0.5]
query_comparison_operator_ratio = [0, 0, 1, 0]
query_logic_predicate_num = [0.6, 0.2, 0.2]
average_aggregation_operator_num = [0.5, 0.3, 0.2]
average_query_column_num = [0, 0.6, 0.3, 0.1]
group_by_ratio_if_read_sql = [0.5, 0.5]
order_by_desc_or_asc_if_grouped = [0.5, 0.5]


# hardware configs
memory = 32

index_weight=1
primary_key_weight=1
