import numpy as np
import json
with open("res.json", 'r') as file:
    json_data = json.load(file)
print(json_data)
for it in json_data.keys():
    print(it)
for i,it in enumerate(json_data['Tables']):
    print(it.keys())
    for i in range(len(it['Column Distribution'])):
        it['Column Distribution'][i]=0
    it['Column Distribution'][0]=1.0
    print(it['Column Distribution'])
    json_data['Tables'][i]=it
with open("res2.json", 'w') as file:
    json.dump(json_data, file, indent=4)