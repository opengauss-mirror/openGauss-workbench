#!/usr/bin/env python
# vim: set fileencoding=utf-8
import paramiko
import re
import json
import argparse
import os
import sys
import time

# # Get the absolute path of the current script
current_path = os.path.abspath(os.path.dirname(__file__))
#
# # Get the absolute path of the config.py file
config_path = os.path.join(current_path, '../../../')
#
# # Add the directory containing config.py to sys.path
sys.path.append(os.path.dirname(config_path))

# Now you can import config.py
import config
#import Database
from Database import Database

# 初始化ssh客户端
def init(config):
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh_client.connect(hostname=config.hostname, username=config.os_user, password=os.environ.get('installPassword'))

    stdin, stdout, stderr = ssh_client.exec_command('whoami')
    output = stdout.read().decode()

    pattern = r"[a-zA-Z]+\n?"
    output_alter = re.sub(pattern, lambda m: m.group().strip(), output)
        
    if output_alter!=config.os_user:
        print("fatal error : not login correctly.")
        
    stdin, stdout, stderr = ssh_client.exec_command('pwd')
    output = stdout.read().decode()

    pattern = r"[a-zA-Z]+\n?"
    output_alter = re.sub(pattern, lambda m: m.group().strip(), output)
    
    print("login success. cwd : ",output_alter)
    return ssh_client

# 语法解析函数
def parseSQL2json2(create_table_sql,tbs_pk):
    one_table={
        "Table Name": "",
        "Table Columns": [],
        "Column Distribution" : [],
        "Primary Key": [],
        "DISTRIBUTE Key": ""
    }
    pk_column={
        "Name": "pk_name",
        "Data Type": ""
    }
    pks = []

    filter_pattern = r"(CREATE TABLE .*)WITH"
    create_table_sql_prum0=re.search(pattern=filter_pattern,string=create_table_sql,flags=re.DOTALL)
    if create_table_sql_prum0 is None:
        print("CREATE SQL error: ", create_table_sql)
        return 

    create_table_sql_prum = create_table_sql_prum0.group(1)

    import psqlparse
    try:
        statements=psqlparse.parse(create_table_sql_prum)
        table_name_match=statements[0]['CreateStmt']['relation']['RangeVar']['relname']
    except Exception as e:
        print("fatal error : sql syntax incorrect.")
        print(f"wrong sql : {create_table_sql_prum}")
        return
    
    index_=1
    columns = []
    for i in statements[0]['CreateStmt']['tableElts']:
        # 各个列
        for j,k in i.items():
            # print(j,":")
            # print(f"{index_} : ")
            one_column={
                "Column Name": 'column_name',
                "Data Type": 'column_type',
                "Data Type Mod": 0,
                "Data Distribution": ["minv","maxv"]
            }
            for m,n in k.items():
                if m=="typeName":
                    one_column["Data Type"]=n['TypeName']['names'][len(n['TypeName']['names'])-1]['String']['str']
                    one_column["Data Type"]=one_column["Data Type"].lower()
                    if one_column["Data Type"][0:3]=="int":
                        one_column["Data Type"]='int'
                    elif one_column["Data Type"][0:5]=="float":
                        one_column["Data Type"]='float'
                    # elif one_column["Data Type"]=="bpchar":
                    #     one_column["Data Type"]='varchar'
                    
                    if one_column["Data Type"] not in supportive_data_type:
                        one_column["Data Type"]="unknown"
                    
                    # 处理typemod
                    # print("\tcoltype : ",n['TypeName']['names'][len(n['TypeName']['names'])-1]['String']['str'])
                    if n['TypeName']['names'][len(n['TypeName']['names'])-1]['String']['str'] in ["varchar","text","tinytext","mediumtext","longtext"]:
                        if "typmods" not in n['TypeName'].keys():
                            one_column["Data Type Mod"]=63
                        else:
                            one_column["Data Type Mod"]=n['TypeName']['typmods'][0]['A_Const']['val']['Integer']['ival']
                    
                    # 处理定长数组bpchar类型
                    elif n['TypeName']['names'][len(n['TypeName']['names'])-1]['String']['str']=="bpchar":
                        one_column["Data Type Mod"]=n['TypeName']['typmods'][0]['A_Const']['val']['Integer']['ival']
                        
                    # timestamp有两种情形，有精度和无精度
                    # 无精度就默认精度最低，也就是0
                    elif n['TypeName']['names'][len(n['TypeName']['names'])-1]['String']['str'] in ('timestamp','date','datetime'):
                        if 'typmods' in n['TypeName'].keys():
                            one_column["Data Type Mod"]=n['TypeName']['typmods'][0]['A_Const']['val']['Integer']['ival']
                        else:
                            one_column["Data Type Mod"]=0
                    # numeric也有两种情形，一维和二维
                    # numeric数据类型需要两个参数，这两个参数分别用于指定数值的总位数和小数位数
                    # 比如，numeric(5,2)代表333.33这种数字
                    elif n['TypeName']['names'][len(n['TypeName']['names'])-1]['String']['str']=='numeric':
                        if 'typmods' in n['TypeName'].keys():
                            one_column['Data Type Mod']=\
                                [n['TypeName']['typmods'][0]['A_Const']['val']['Integer']['ival'],
                                n['TypeName']['typmods'][1]['A_Const']['val']['Integer']['ival']]
                        else:
                            one_column['Data Type Mod']=[10,0]
                    
                    # 设置缺省值域
                    if one_column["Data Type"] in ['varchar','text','tinytext','mediumtext','longtext']:
                        lower=max(1,int(one_column["Data Type Mod"]/2))
                        #higher=max(lower,one_column["Data Type Mod"]-2)
                        #one_column["Data Distribution"]=[lower,higher]
                        one_column["Data Distribution"]=[1,lower]
                    elif one_column["Data Type"] in ["bpchar"]:
                        one_column["Data Distribution"]=[one_column["Data Type Mod"],one_column["Data Type Mod"]]
                    elif one_column["Data Type"] in ["int","float","double","bigint"]:
                        one_column["Data Distribution"]=[0,9999]
                    elif one_column["Data Type"] in ["tinyint"]:
                        one_column["Data Distribution"]=[0,127]
                    elif one_column["Data Type"] in ["numeric"]:
                        # one_column["Data Distribution"]=[1,100]
                        one_column["Data Distribution"]=\
                            [   
                                0,
                                9999
                                #10**(one_column['Data Type Mod'][0]-one_column['Data Type Mod'][1])-1
                            ]
                    elif one_column["Data Type"] in ["timestamp",'date','datetime']:
                        one_column["Data Distribution"]=["1900-11-02 0:0:0","2023-9-1 0:0:0"]
                    else:
                        one_column["Data Distribution"]=["unknown","unknown"]
                    
                elif m=="colname":
                    index_+=1
                    # print("\tcolname : ",n)
                    one_column["Column Name"]=n
                else:
                    pass
            columns.append(one_column)
    
            
    one_table["Table Name"]=table_name_match
    one_table["Table Columns"]=columns
    
    one_table["Column Distribution"]=[1.0/len(columns) for i in range(len(columns))]
   
    # 分布键
    filter_dis = r"DISTRIBUTE BY .* \((.*)\)"
    dis_key0 = re.search(pattern=filter_dis,string=create_table_sql,flags=re.DOTALL)
    if dis_key0 is not None:
        dis_key = dis_key0.group(1)
        if dis_key is not None:
            one_table["DISTRIBUTE Key"] = dis_key.replace(' ','')

    # 主键
    if table_name_match in tbs_pk:
        cols = ','.join(tbs_pk[table_name_match])
        pk_column["Name"]=cols
        pks.append(pk_column)

        one_table["Primary Key"]=pks
    else:
        one_table["Primary Key"] = ""

    return one_table
    
# 解析索引
def parseSQL2json3(create_index_sql,tb_info):
    filter_pattern = r"(CREATE INDEX .*)"
    #filter_pattern = r"(CREATE INDEX .*|CONSTRAINT .*)"
    new_sql = create_index_sql.replace('\n','')
    #filter_pattern = r"(ALTER TABLE .*)"
    create_index_sql_prum0=re.search(pattern=filter_pattern,string=new_sql,flags=re.DOTALL)
    if create_index_sql_prum0 is None:
        print("INDEX SQL match error: ",create_index_sql)
        return
    create_index_sql_prum = create_index_sql_prum0.group(1)

    import psqlparse
    try:
        statements=psqlparse.parse(create_index_sql_prum)
        col_names_match=[]
        
        for i in range(len(statements[0]['IndexStmt']['indexParams'])):
            col_names_match.append(statements[0]['IndexStmt']['indexParams'][i]['IndexElem']['name'])
        tb_name_match=statements[0]['IndexStmt']['relation']['RangeVar']['relname']
    except Exception as e:
        print("fatal error : CREATE INDEX sql syntax incorrect.")
        print(f"wrong sql : {create_index_sql}")
        return

    # print(col_name_match)
    # print(tb_name_match)
    for col_name_match in col_names_match:
        if tb_name_match in tb_info.keys():
            tb_info[tb_name_match][col_name_match]=2
        else:
            tb_info[tb_name_match]=dict()
            tb_info[tb_name_match][col_name_match]=2
    
# 解析主键和唯一键、分布键，用于ON DUPLICATE KEY UPDATE
def parseSQL2json4(primary_sqls):
    pk = dict()
    col_names = []
    for it in primary_sqls:

        #filter_pattern = r"(ALTER TABLE .* ADD CONSTRAINT .* PRIMARY KEY .*)"
        filter_pattern = r"(ALTER TABLE .* ADD CONSTRAINT .*\))"
        create_primary_sql_prum0=re.search(pattern=filter_pattern,string=it,flags=re.DOTALL)
        if create_primary_sql_prum0 is None:
            print("ALTER SQL match error: ",create_index_sql)
            return
        create_primary_sql_prum = create_primary_sql_prum0.group(1).replace('USING ubtree','')
        #print(create_primary_sql_prum,'--------',create_primary_sql_prum0)

        import psqlparse
        try:
            statements=psqlparse.parse(create_primary_sql_prum)
            col_names_match=[]
            for i in range(len(statements[0]['AlterTableStmt']['cmds'][0]['AlterTableCmd']['def']['Constraint']['keys'])):
                col_names_match.append(statements[0]['AlterTableStmt']['cmds'][0]['AlterTableCmd']['def']['Constraint']['keys'][i]['String']['str'])
            tb_name_match=statements[0]['AlterTableStmt']['relation']['RangeVar']['relname']
        except Exception as e:
            print("fatal error : ALTER TABLE sql syntax incorrect.", e)
            print(f"wrong sql : {create_primary_sql_prum}")
            return

        col = ''.join(col_names_match)
        if tb_name_match in pk:
            pk[tb_name_match] = pk[tb_name_match] + col_names_match
        else:
            pk[tb_name_match] = col_names_match

    #print(">>>>>>>>>",pk)
    return pk
    '''
    # print(tb_name_match)
    for col_name_match in col_names_match:
        if tb_name_match in tb_info.keys():
            tb_info[tb_name_match][col_name_match]=1
        else:
            tb_info[tb_name_match]=dict()
            tb_info[tb_name_match][col_name_match]=1
    '''

if __name__=="__main__":
    print("Extraction start.")
    
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--hostname', type=str, default=config.host)
    parser.add_argument('--os_user', type=str, default=config.os_user)
    parser.add_argument('--username', type=str, default=config.user)
    parser.add_argument('--omm_password', type=str, default=os.environ.get('installPassword'))
    parser.add_argument('--user_password', type=str, default=os.environ.get('dbPassword'))
    parser.add_argument('--sql_path', type=str, default=config.remote_cache_path)
    parser.add_argument('--port', type=int, default=config.port)
    parser.add_argument('--database_name', type=str, default=config.db)
    parser.add_argument('--schema_name', type=str, default=config.schema_name)
    parser.add_argument('--use_local', type=str, default=config.use_local)
    parser.add_argument('--cache_path', type=str, default=config.local_cache_path)
    parser.add_argument('--result_path', type=str, default=config.json_extract_result_path)
    
    
    parser.add_argument('--index_weight', type=str, default=config.index_weight)
    parser.add_argument('--primary_key_weight', type=str, default=config.primary_key_weight)
    parser.add_argument('--workload', type=str, default=config.workload)
    
    supportive_data_type=[
        'varchar','bpchar','text','tinytext','mediumtext','longtext',
        'int','tinyint','bigint',
        'float','double','numeric',
        'timestamp','date','datetime'
    ]
    
    args = parser.parse_args()
    #r_path = '/var/chroot' + args.sql_path
    r_path = args.sql_path
    l_path = '../../../' + args.cache_path
    j_path = '../../../' + args.result_path

    ###############测试行，连接本地的sql文件
    #args.use_local='True'
    if args.use_local=='false':
        ssh_client=init(args)
        #shell = Database.get_shell(Database,ssh_client)
        
        #command=f"ls"
        #command=f"source ~/gauss_env_file && gs_dump -U {args.username} -f {args.sql_path} -p {args.port} -s {args.database_name} -n {args.schema_name} -F p \n"
        command=f"gs_dump -U {args.username} -f {args.sql_path} -p {args.port} -s {args.database_name} -n {args.schema_name} -F p \n"
        # command = "gs_dump -U jikun -f /home/tianjikun/schema/test.sql -p 15400 dwg -n public -F p"
        print("command : ",command)
        #shell.send(command)
        #time.sleep(60)
        #output = shell.recv(1024)
        #info = output.decode('utf-8')
        stdin, stdout, stderr = ssh_client.exec_command(command=command)
        stdin.write(f'{args.user_password}\n')
        stdin.flush()
        output = stdout.read().decode()

        sftp_client = ssh_client.open_sftp()
        sftp_client.get(localpath=l_path, remotepath=r_path)
        sftp_client.close()

        with open(l_path, 'r') as f:
            content=f.read()
        #print(type(content),len(content))
    
    else:
        print(f"Warning : using local file {args.sql_path}.")
        
        with open(args.sql_path, 'r') as f:
            content=f.read()
        #print(type(content),len(content))

    content_split=re.split('[\n]*;+[\n]*',content)
    #print(len(content_split))
    # content_split = re.sub('\n', '', content_split)
    real_content=[]
    real_index_content=[]
    real_primary_content=[]
    for it in content_split:
        # if "CREATE" in it and "GRANT" not in it and "INDEX" not in it:
            # print(it)
            # real_content.append(it)
        #pk_pattern = r"(ALTER TABLE .*)"
        #if re.search(pattern=pk_pattern,string=it,flags=re.DOTALL)!=None:
        #    print('=======',it)

        filter_pattern = r"(CREATE TABLE .*)WITH"
        if re.search(pattern=filter_pattern,string=it,flags=re.DOTALL)!=None:
            # print(it)
            real_content.append(it)
        
        filter_pattern = r"(CREATE INDEX .*)"
        if re.search(pattern=filter_pattern,string=it,flags=re.DOTALL)!=None:
            #print('~~~~~~~~~~~~~',it)
            real_index_content.append(it)
            
        #filter_pattern = r"(ALTER TABLE .* ADD CONSTRAINT .* PRIMARY KEY .*)"
        filter_pattern = r"(ALTER TABLE .* ADD CONSTRAINT .*)"
        if re.search(pattern=filter_pattern,string=it,flags=re.DOTALL)!=None:
            #print('----------',it)
            real_primary_content.append(it)

    json_data={
        "Table Schema": args.schema_name,
        "Tables": [],
        "Constraints": {
        "size of workload" : config.sql_num,
        "read write ratio": config.read_write_ratio,
        "average table num": config.averageTableNum,
        "table-query access distribution": [],
        "query comparison operator ratio" : config.query_comparison_operator_ratio,
        "table domain distribution" : config.table_domain_distribution,
        "query logic predicate num" : config.query_logic_predicate_num,
        "average aggregation operator num" : config.average_aggregation_operator_num,
        "average query colomn num": config.average_query_column_num,
        "group by ratio if read SQL":config.group_by_ratio_if_read_sql,
        "order by desc or asc if grouped":config.order_by_desc_or_asc_if_grouped
        },
        "Generation File": args.workload
    }

    tbs_pk = parseSQL2json4(real_primary_content)

    tables=[]
    for it in real_content:
        one_table=parseSQL2json2(it,tbs_pk)
        tables.append(one_table)
    json_data["Tables"]=tables
    import numpy as np
    json_data["Constraints"]["table-query access distribution"]\
        =np.full(len(json_data["Tables"]),1.0/len(json_data["Tables"])).tolist()
    
    tbs_col_info=dict()
    for it in real_index_content:
        parseSQL2json3(it,tbs_col_info)
        # 枚举每个表，对每个表进行更改
        # 处理出来每个表的每个列是否是索引，是否是主键，需要这么一个map
    
    print("---------------------------")
    
    #for it in real_primary_content:
    #    parseSQL2json4(it,tbs_col_info)
    


    for it in json_data["Tables"]:
        _cnt1=0
        _cnt2=0
        for it_col in it['Table Columns']:
            if it['Table Name'] in tbs_col_info.keys() and \
                it_col['Column Name'] in tbs_col_info[it['Table Name']]:
                if tbs_col_info[it['Table Name']][it_col['Column Name']]==1:
                    _cnt2+=1
                elif tbs_col_info[it['Table Name']][it_col['Column Name']]==2:
                    _cnt1+=1
            else:
                pass
        
        # print(it["Column Distribution"])
        # print(_cnt1,_cnt2)
        if _cnt1+_cnt2==0:
            pass
        else:
            _index=0
            for it_col in it['Table Columns']:
                # print(it['Table Name'],it_col['Column Name'])
                if it['Table Name'] in tbs_col_info.keys() and \
                    it_col['Column Name'] in tbs_col_info[it['Table Name']]:
                    if tbs_col_info[it['Table Name']][it_col['Column Name']]==1:
                        it["Column Distribution"][_index]=args.primary_key_weight/_cnt2
                    elif tbs_col_info[it['Table Name']][it_col['Column Name']]==2:
                        it["Column Distribution"][_index]=args.index_weight/_cnt1
                    
                else:
                    last_weight=1
                    if _cnt1>0:
                        last_weight-=args.index_weight
                    if _cnt2>0:
                        last_weight-=args.primary_key_weight
                    it["Column Distribution"][_index]=last_weight/(len(it["Column Distribution"])-_cnt1-_cnt2)
                _index+=1
        # print(it["Column Distribution"],sum(it["Column Distribution"]))
        
    with open(j_path, "w") as f:
        json.dump(json_data, f, indent=4)
        print("parse succeeded.")
        print("result written in {}".format(j_path))
    
    if args.use_local=="false":
        ssh_client.close()
    else:
        pass
    
