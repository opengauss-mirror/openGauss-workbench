# Custom: writing your own BO algorithm

We'll introduce how you can use this BO library to write your own BO algorithm

## Extend design space

## New surrogate model

## New acquisition function
