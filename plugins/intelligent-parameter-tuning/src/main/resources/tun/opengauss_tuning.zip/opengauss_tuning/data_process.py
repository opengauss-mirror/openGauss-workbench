import sqlite3


class data_process:

    def __init__(self, db, tuning='../../../tuning.db'):
        self.conn = sqlite3.connect(tuning)
        self.cursor = self.conn.cursor()

    def insert_data(self, training_id, tuning_round, parameter_type, running_time, training_parameter, tps):
        self.cursor.execute('''INSERT INTO training_progress (training_id, tuning_round, parameter_type, running_time, training_parameter, tps)
                            VALUES (?, ?, ?, ?, ?, ?)''',
                            (training_id, tuning_round, parameter_type, running_time, training_parameter, tps))
        self.conn.commit()

    def close_connection(self):
        self.cursor.close()
        self.conn.close()
