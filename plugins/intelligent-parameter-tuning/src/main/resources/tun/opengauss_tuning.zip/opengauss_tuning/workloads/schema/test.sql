--
-- GaussDB database dump
--

SET statement_timeout = 0;
SET xmloption = content;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: db_newsql_movie; Type: SCHEMA; Schema: -; Owner: gaussdb
--

CREATE SCHEMA db_newsql_movie;


ALTER SCHEMA db_newsql_movie OWNER TO gaussdb;

SET search_path = db_newsql_movie;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: t_ucp_as_attachment; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_as_attachment (
    objectid bigint NOT NULL,
    fileid character varying NOT NULL,
    attachmenttype integer DEFAULT 0,
    downloadurl character varying,
    uploadurl character varying,
    status integer DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_as_attachment OWNER TO gaussdb;

--
-- Name: t_ucp_audit_mode; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_audit_mode (
    auditid bigint NOT NULL,
    type tinyint NOT NULL,
    projectid character varying NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_audit_mode OWNER TO gaussdb;

--
-- Name: t_ucp_comment_audit; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_comment_audit (
    contentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    commentid character varying NOT NULL,
    mentionscommentid character varying,
    comment text NOT NULL,
    contentthumb character varying,
    encuserid character varying,
    nickname character varying,
    avatar character varying,
    mentionsencuserid character varying,
    mentionsnickname character varying,
    devicetype character varying,
    devicenickname character varying,
    createtime bigint NOT NULL,
    riskreturntime bigint DEFAULT 0,
    starrating bigint DEFAULT 0,
    clientversion character varying,
    extensions character varying,
    status bigint NOT NULL,
    shauserid character varying NOT NULL,
    commenttype tinyint DEFAULT 0,
    auditmode tinyint DEFAULT 0,
    countrycodes character varying,
    nlpresult character varying,
    operreplycount bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_comment_audit OWNER TO gaussdb;

--
-- Name: t_ucp_comment_backup; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_comment_backup (
    contentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    commentid character varying NOT NULL,
    commenttype tinyint DEFAULT 0,
    mentionscommentid character varying,
    comment text NOT NULL,
    contentthumb character varying,
    encuserid character varying,
    nickname character varying,
    avatar character varying,
    mentionsencuserid character varying,
    mentionsnickname character varying,
    likescount integer DEFAULT 0,
    operlikescount integer DEFAULT 0,
    dislikescount integer DEFAULT 0,
    reportscount integer DEFAULT 0,
    sharescount integer DEFAULT 0,
    replycount integer DEFAULT 0,
    devicetype character varying,
    devicenickname character varying,
    starrating bigint DEFAULT 0,
    clientversion character varying,
    createtime bigint NOT NULL,
    riskreturntime bigint DEFAULT 0,
    onlinetime bigint DEFAULT 0,
    offlinetime bigint DEFAULT 0,
    offlinetype tinyint DEFAULT 0,
    expiretime bigint NOT NULL,
    extensions character varying,
    status tinyint NOT NULL,
    reportonlinestatus tinyint DEFAULT 0,
    commentstatus tinyint NOT NULL,
    shauserid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_comment_backup OWNER TO gaussdb;

--
-- Name: t_ucp_comment_content; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_comment_content (
    contentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    commentcount bigint DEFAULT 0,
    wonderfulcommentcount bigint DEFAULT 0,
    onestarratingcount bigint DEFAULT 0,
    twostarratingcount bigint DEFAULT 0,
    threestarratingcount bigint DEFAULT 0,
    fourstarratingcount bigint DEFAULT 0,
    fivestarratingcount bigint DEFAULT 0,
    latestcommentreplycount bigint DEFAULT 0,
    wonderfulcommentreplycount bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_comment_content OWNER TO gaussdb;

--
-- Name: t_ucp_comment_offline; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_comment_offline (
    contentid character varying NOT NULL,
    commentid character varying NOT NULL,
    mentionscommentid character varying,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    comment text NOT NULL,
    contentthumb character varying,
    encuserid character varying NOT NULL,
    nickname character varying,
    avatar character varying,
    likescount bigint DEFAULT 0,
    mentionsencuserid character varying,
    mentionsnickname character varying,
    operlikescount bigint DEFAULT 0,
    reportscount bigint DEFAULT 0,
    dislikescount bigint DEFAULT 0,
    sharescount bigint DEFAULT 0,
    replycount bigint DEFAULT 0,
    devicetype character varying,
    devicenickname character varying,
    createtime bigint NOT NULL,
    onlinetime bigint NOT NULL,
    clientversion character varying,
    extensions character varying,
    starrating bigint DEFAULT 0,
    offlinetype bigint DEFAULT 3,
    offlinetime bigint NOT NULL,
    shauserid character varying NOT NULL,
    mentionsshauserid character varying,
    commenttype bigint DEFAULT 0,
    reason character varying,
    updatetime bigint DEFAULT 0,
    countrycodes character varying,
    nlpresult character varying,
    operreplycount bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_comment_offline OWNER TO gaussdb;

--
-- Name: t_ucp_comment_online; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_comment_online (
    contentid character varying NOT NULL,
    commentid character varying NOT NULL,
    mentionscommentid character varying,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    comment text NOT NULL,
    contentthumb character varying,
    encuserid character varying NOT NULL,
    nickname character varying,
    avatar character varying,
    likescount bigint DEFAULT 0,
    mentionsencuserid character varying,
    mentionsnickname character varying,
    operlikescount bigint DEFAULT 0,
    reportscount bigint DEFAULT 0,
    dislikescount bigint DEFAULT 0,
    sharescount bigint DEFAULT 0,
    replycount bigint DEFAULT 0,
    devicetype character varying,
    devicenickname character varying,
    createtime bigint NOT NULL,
    onlinetime bigint NOT NULL,
    clientversion character varying,
    extensions character varying,
    starrating bigint DEFAULT 0,
    commentreplys character varying,
    reportonlinestatus bigint DEFAULT 0,
    shauserid character varying NOT NULL,
    mentionsshauserid character varying,
    commenttype bigint DEFAULT 0,
    iswonderful tinyint DEFAULT 0,
    wonderfulcreatetime bigint DEFAULT 0,
    reason character varying,
    updatetime bigint DEFAULT 0,
    countrycodes character varying,
    offlinetype bigint DEFAULT 0,
    nlpresult character varying,
    operreplycount bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_comment_online OWNER TO gaussdb;

--
-- Name: t_ucp_comment_wonderful; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_comment_wonderful (
    contentid character varying NOT NULL,
    commentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    createtime bigint NOT NULL,
    wonderfulcommentcreatetime bigint DEFAULT 0,
    wonderfulcommenttype character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_comment_wonderful OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_audit; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_audit (
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    contentid character varying NOT NULL,
    danmuid character varying NOT NULL,
    contentthumb character varying,
    danmu character varying NOT NULL,
    danmustyle character varying,
    danmutype character varying,
    encuserid character varying,
    tag character varying NOT NULL,
    timeoffset bigint DEFAULT 0,
    createtime bigint DEFAULT 0,
    extensions character varying,
    status bigint DEFAULT 0,
    shauserid character varying NOT NULL,
    auditmode tinyint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_audit OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_backup; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_backup (
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    contentid character varying NOT NULL,
    danmuid character varying NOT NULL,
    danmukey character varying NOT NULL,
    contentthumb character varying,
    danmu character varying NOT NULL,
    danmustyle character varying,
    danmutype character varying,
    encuserid character varying,
    tag character varying NOT NULL,
    timeoffset bigint DEFAULT 0,
    createtime bigint DEFAULT 0,
    extensions character varying,
    status bigint DEFAULT 0,
    likescount bigint DEFAULT 0,
    reportscount bigint DEFAULT 0,
    shauserid character varying NOT NULL,
    expiretime bigint DEFAULT 0 NOT NULL,
    offlinetype bigint DEFAULT 0,
    danmustatus bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_backup OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_content_clips; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_content_clips (
    danmukey character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    contentid character varying NOT NULL,
    clipid character varying NOT NULL,
    danmucount integer DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_content_clips OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_display; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_display (
    danmukey character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    contentid character varying NOT NULL,
    contentthumb character varying,
    danmujson character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_display OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_live_audit; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_live_audit (
    danmuid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    roomid character varying NOT NULL,
    roomname character varying,
    danmu character varying,
    messagetype integer NOT NULL,
    clienttag character varying,
    userlevel tinyint,
    danmulevel tinyint NOT NULL,
    danmustyle character varying,
    danmutype character varying,
    encuserid character varying NOT NULL,
    nickname character varying,
    createtime bigint NOT NULL,
    extensions character varying,
    serverextensions character varying,
    status tinyint NOT NULL,
    shauserid character varying NOT NULL,
    storetype tinyint NOT NULL,
    auditflag tinyint DEFAULT 0,
    danmugroupnumber tinyint DEFAULT 1,
    roomidlist character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_live_audit OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_live_offline; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_live_offline (
    roomid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    danmuid character varying NOT NULL,
    roomname character varying,
    danmu character varying,
    messagetype integer NOT NULL,
    clienttag character varying,
    userlevel integer,
    danmulevel integer NOT NULL,
    danmustyle character varying,
    danmutype character varying,
    encuserid character varying,
    nickname character varying,
    createtime bigint DEFAULT 0,
    reviewtime bigint DEFAULT 0,
    likescount integer DEFAULT 0,
    reportscount integer DEFAULT 0,
    offlinetype tinyint,
    extensions character varying,
    serverextensions character varying,
    shauserid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_live_offline OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_live_online; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_live_online (
    roomid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    danmuid character varying NOT NULL,
    roomname character varying,
    danmu character varying,
    messagetype integer NOT NULL,
    clienttag character varying,
    userlevel integer,
    danmulevel integer NOT NULL,
    danmustyle character varying,
    danmutype character varying,
    encuserid character varying,
    nickname character varying,
    createtime bigint DEFAULT 0,
    reviewtime bigint DEFAULT 0,
    likescount integer DEFAULT 0,
    reportscount integer DEFAULT 0,
    extensions character varying,
    serverextensions character varying,
    shauserid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_live_online OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_offline; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_offline (
    danmukey character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    contentid character varying NOT NULL,
    danmuid character varying NOT NULL,
    contentthumb character varying,
    danmu character varying NOT NULL,
    danmustyle character varying,
    danmutype character varying,
    encuserid character varying,
    tag character varying NOT NULL,
    timeoffset bigint DEFAULT 0,
    createtime bigint DEFAULT 0,
    likescount integer DEFAULT 0,
    reportscount integer DEFAULT 0,
    offlinetype tinyint,
    extensions character varying,
    shauserid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_offline OWNER TO gaussdb;

--
-- Name: t_ucp_danmu_online; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_danmu_online (
    danmukey character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    contentid character varying NOT NULL,
    danmuid character varying NOT NULL,
    contentthumb character varying,
    danmu character varying NOT NULL,
    danmustyle character varying,
    danmutype character varying,
    encuserid character varying,
    tag character varying NOT NULL,
    timeoffset bigint DEFAULT 0,
    createtime bigint DEFAULT 0,
    likescount integer DEFAULT 0,
    reportscount integer DEFAULT 0,
    extensions character varying,
    shauserid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_danmu_online OWNER TO gaussdb;

--
-- Name: t_ucp_event_audit; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_event_audit (
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    encuserid character varying,
    shauserid character varying NOT NULL,
    operationtype character varying NOT NULL,
    requestmessage character varying,
    result character varying NOT NULL,
    ipaddresses character varying NOT NULL,
    requestid character varying,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_event_audit OWNER TO gaussdb;

--
-- Name: t_ucp_gs_group_user; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_gs_group_user (
    groupid character varying NOT NULL,
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    role tinyint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_gs_group_user OWNER TO gaussdb;

--
-- Name: t_ucp_id_mapping; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_id_mapping (
    outerid character varying NOT NULL,
    innerid bigint NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    type tinyint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_id_mapping OWNER TO gaussdb;

--
-- Name: t_ucp_is_sign_in; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_is_sign_in (
    shauserid character varying NOT NULL,
    objectid character varying NOT NULL,
    encuserid character varying NOT NULL,
    signcontent character varying,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_is_sign_in OWNER TO gaussdb;

--
-- Name: t_ucp_is_user_like; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_is_user_like (
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    objectid character varying NOT NULL,
    encuserid character varying,
    shauserid character varying NOT NULL,
    objecttype integer DEFAULT 0,
    createtime bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_is_user_like OWNER TO gaussdb;

--
-- Name: t_ucp_is_user_report; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_is_user_report (
    objectid character varying NOT NULL,
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    level tinyint DEFAULT 0,
    content character varying,
    objecttype tinyint DEFAULT 0,
    reporttype tinyint DEFAULT 0,
    extensions character varying,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    createtime bigint NOT NULL,
    updatetime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_is_user_report OWNER TO gaussdb;

--
-- Name: t_ucp_is_voter; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_is_voter (
    shauserid character varying NOT NULL,
    objectid character varying NOT NULL,
    votertype tinyint DEFAULT 0,
    encuserid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_is_voter OWNER TO gaussdb;

--
-- Name: t_ucp_liveroom; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_liveroom (
    roomid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    roomname character varying NOT NULL,
    cdnlink character varying NOT NULL,
    directoryid character varying NOT NULL,
    visitornumber integer DEFAULT 0,
    starttime bigint NOT NULL,
    endtime bigint,
    createtime bigint NOT NULL,
    updatetime bigint NOT NULL,
    auditnumber tinyint DEFAULT 1,
    cdndownloadurl character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_liveroom OWNER TO gaussdb;

--
-- Name: t_ucp_moment_data_count; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_moment_data_count (
    count_time bigint NOT NULL,
    posts_count bigint NOT NULL,
    comments_count bigint NOT NULL,
    likes_count bigint NOT NULL,
    feeds_count bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_moment_data_count OWNER TO gaussdb;

--
-- Name: t_ucp_reply_backup; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_reply_backup (
    contentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    commentid character varying NOT NULL,
    replyid character varying NOT NULL,
    reply character varying NOT NULL,
    mentionsreplyid character varying,
    mentionsencuserid character varying,
    mentionsnickname character varying,
    encuserid character varying,
    shauserid character varying NOT NULL,
    nickname character varying,
    avatar character varying,
    likescount integer DEFAULT 0,
    operlikescount integer DEFAULT 0,
    dislikescount integer DEFAULT 0,
    reportscount integer DEFAULT 0,
    sharescount integer DEFAULT 0,
    devicetype character varying,
    devicenickname character varying,
    createtime bigint NOT NULL,
    expiretime bigint NOT NULL,
    extensions character varying,
    rejecttype tinyint,
    status tinyint NOT NULL,
    replystatus tinyint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_reply_backup OWNER TO gaussdb;

--
-- Name: t_ucp_reply_offline; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_reply_offline (
    commentid character varying NOT NULL,
    projectid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    scenes character varying NOT NULL,
    replyid character varying NOT NULL,
    reply character varying NOT NULL,
    contentid character varying NOT NULL,
    encuserid character varying NOT NULL,
    nickname character varying,
    mentionsencuserid character varying,
    mentionsnickname character varying,
    mentionsreplyid character varying,
    avatar character varying,
    likescount bigint DEFAULT 0,
    operlikescount bigint DEFAULT 0,
    dislikescount bigint DEFAULT 0,
    reportscount bigint DEFAULT 0,
    sharescount bigint DEFAULT 0,
    devicetype character varying,
    devicenickname character varying,
    createtime bigint NOT NULL,
    extensions character varying,
    rejecttype bigint DEFAULT 0,
    shauserid character varying NOT NULL,
    mentionsshauserid character varying,
    reason character varying,
    updatetime bigint DEFAULT 0,
    countrycodes character varying,
    nlpresult character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_reply_offline OWNER TO gaussdb;

--
-- Name: t_ucp_reply_online; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_reply_online (
    commentid character varying NOT NULL,
    replyid character varying NOT NULL,
    projectid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    scenes character varying NOT NULL,
    reply character varying NOT NULL,
    contentid character varying NOT NULL,
    mentionsencuserid character varying,
    mentionsnickname character varying,
    mentionsreplyid character varying,
    encuserid character varying NOT NULL,
    nickname character varying,
    avatar character varying,
    likescount bigint DEFAULT 0,
    operlikescount bigint DEFAULT 0,
    dislikescount bigint DEFAULT 0,
    reportscount bigint DEFAULT 0,
    sharescount bigint DEFAULT 0,
    devicetype character varying,
    devicenickname character varying,
    createtime bigint NOT NULL,
    extensions character varying,
    shauserid character varying NOT NULL,
    mentionsshauserid character varying,
    reason character varying,
    updatetime bigint DEFAULT 0,
    countrycodes character varying,
    rejecttype bigint DEFAULT 0,
    nlpresult character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_reply_online OWNER TO gaussdb;

--
-- Name: t_ucp_reply_risk; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_reply_risk (
    contentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    commentid character varying NOT NULL,
    replyid character varying NOT NULL,
    reply character varying,
    encuserid character varying,
    nickname character varying,
    avatar character varying,
    atencuserid character varying,
    atnickname character varying,
    devicetype character varying,
    devicenickname character varying,
    createtime bigint NOT NULL,
    extensions character varying,
    status bigint DEFAULT 0,
    atreplyid character varying,
    shauserid character varying NOT NULL,
    auditmode tinyint DEFAULT 0,
    countrycodes character varying,
    nlpresult character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_reply_risk OWNER TO gaussdb;

--
-- Name: t_ucp_toast; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_toast (
    toastid bigint NOT NULL,
    type tinyint NOT NULL,
    toastwords character varying NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_toast OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_content; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_content (
    content_id bigint NOT NULL,
    app_id character varying NOT NULL,
    hc character varying NOT NULL,
    project_id character varying NOT NULL,
    scenes character varying DEFAULT 'MusicCircle'::character varying NOT NULL,
    group_id bigint NOT NULL,
    type tinyint NOT NULL,
    title character varying NOT NULL,
    status tinyint,
    sha_user_id character varying NOT NULL,
    enc_user_id character varying,
    comments_count integer DEFAULT 0,
    likes_count integer DEFAULT 0,
    shares_count integer DEFAULT 0,
    reports_count integer DEFAULT 0,
    rank integer DEFAULT 0,
    review_result character varying,
    sys_publish tinyint NOT NULL,
    create_time bigint NOT NULL,
    update_time bigint NOT NULL,
    heat character varying,
    sys_audit_status tinyint DEFAULT 1,
    manual_audit_status tinyint DEFAULT 1,
    ext1 character varying,
    ext2 character varying,
    ext3 character varying,
    ext4 character varying,
    ext5 character varying,
    anonymous tinyint DEFAULT 1,
    collects_count bigint DEFAULT 0,
    browses_count bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_content OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_content_detail; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_content_detail (
    contentid character varying NOT NULL,
    content character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_content_detail OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_content_detail_backup; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_content_detail_backup (
    contentid character varying NOT NULL,
    content character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_content_detail_backup OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_content_tag_relation; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_content_tag_relation (
    content_id bigint NOT NULL,
    tag character varying NOT NULL,
    app_id character varying NOT NULL,
    hc character varying NOT NULL,
    project_id character varying NOT NULL,
    scenes character varying NOT NULL,
    scope bigint DEFAULT 1,
    create_time bigint NOT NULL,
    update_time bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_content_tag_relation OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_mute; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_mute (
    roomid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    encuserid character varying NOT NULL,
    shauserid character varying NOT NULL,
    roomname character varying,
    starttime bigint NOT NULL,
    endtime bigint NOT NULL,
    mutetype tinyint NOT NULL,
    mutereason character varying,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_mute OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_topic_post; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_topic_post (
    topic_id bigint NOT NULL,
    post_id bigint NOT NULL,
    app_id character varying NOT NULL,
    hc character varying NOT NULL,
    project_id character varying NOT NULL,
    create_time bigint,
    update_time bigint
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_topic_post OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_user; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_user (
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    contentscount bigint DEFAULT 0,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_user OWNER TO gaussdb;

--
-- Name: t_ucp_ucs_user_content; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_ucs_user_content (
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    contenttype tinyint DEFAULT 0,
    contentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    groupid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_ucs_user_content OWNER TO gaussdb;

--
-- Name: t_ucp_us_user; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_us_user (
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    groupscount bigint DEFAULT 0,
    followerscount bigint DEFAULT 0,
    followingscount bigint DEFAULT 0,
    contentscount bigint DEFAULT 0,
    mutualfollowscount bigint DEFAULT 0,
    likescount bigint DEFAULT 0,
    usertype tinyint DEFAULT 0,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_us_user OWNER TO gaussdb;

--
-- Name: t_ucp_us_user_group; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_us_user_group (
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    groupid character varying NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_us_user_group OWNER TO gaussdb;

--
-- Name: t_ucp_us_user_relation; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_us_user_relation (
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    relationtype bigint DEFAULT 0 NOT NULL,
    shatargetuserid character varying NOT NULL,
    enctargetuserid character varying NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_us_user_relation OWNER TO gaussdb;

--
-- Name: t_ucp_user_collect; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_user_collect (
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    objectid character varying NOT NULL,
    favoriteid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    createtime bigint DEFAULT 0,
    updatetime bigint DEFAULT 0,
    extensions character varying
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_user_collect OWNER TO gaussdb;

--
-- Name: t_ucp_user_comment; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_user_comment (
    shauserid character varying NOT NULL,
    contentid character varying NOT NULL,
    commentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    encuserid character varying NOT NULL,
    status bigint NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_user_comment OWNER TO gaussdb;

--
-- Name: t_ucp_user_comment_count; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_user_comment_count (
    shauserid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    contentid character varying NOT NULL,
    status bigint NOT NULL,
    commentcount bigint DEFAULT 0
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_user_comment_count OWNER TO gaussdb;

--
-- Name: t_ucp_user_footprints; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_user_footprints (
    objectid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    createtime bigint,
    updatetime bigint
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_user_footprints OWNER TO gaussdb;

--
-- Name: t_ucp_user_footprints_detail; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_user_footprints_detail (
    objectid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    shauserid character varying NOT NULL,
    encuserid character varying NOT NULL,
    extensions character varying,
    createtime bigint,
    updatetime bigint
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_user_footprints_detail OWNER TO gaussdb;

--
-- Name: t_ucp_user_reply; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_user_reply (
    shauserid character varying NOT NULL,
    contentid character varying NOT NULL,
    commentid character varying NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    encuserid character varying NOT NULL,
    replyid character varying NOT NULL,
    status bigint NOT NULL,
    createtime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_user_reply OWNER TO gaussdb;

--
-- Name: t_ucp_worker; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucp_worker (
    datacenter integer NOT NULL,
    serverip character varying NOT NULL,
    workerid integer NOT NULL,
    createtime bigint NOT NULL,
    updatetime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucp_worker OWNER TO gaussdb;

--
-- Name: t_ucs_comment_back_track_result; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucs_comment_back_track_result (
    taskid character varying NOT NULL,
    clipid bigint NOT NULL,
    resourcetype tinyint NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    result character varying,
    createtime bigint NOT NULL,
    updatetime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucs_comment_back_track_result OWNER TO gaussdb;

--
-- Name: t_ucs_comment_back_track_task; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucs_comment_back_track_task (
    taskid character varying NOT NULL,
    resourcetype tinyint NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    taskstatus tinyint NOT NULL,
    taskinfo character varying NOT NULL,
    endtime bigint NOT NULL,
    createtime bigint NOT NULL,
    updatetime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucs_comment_back_track_task OWNER TO gaussdb;

--
-- Name: t_ucs_content_back_track_result; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucs_content_back_track_result (
    taskid character varying NOT NULL,
    clipid bigint NOT NULL,
    resourcetype tinyint NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    result character varying,
    createtime bigint NOT NULL,
    updatetime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucs_content_back_track_result OWNER TO gaussdb;

--
-- Name: t_ucs_content_back_track_task; Type: TABLE; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE TABLE t_ucs_content_back_track_task (
    taskid character varying NOT NULL,
    resourcetype tinyint NOT NULL,
    appid character varying NOT NULL,
    hc character varying NOT NULL,
    projectid character varying NOT NULL,
    scenes character varying NOT NULL,
    taskstatus tinyint NOT NULL,
    taskinfo character varying NOT NULL,
    endtime bigint NOT NULL,
    createtime bigint NOT NULL,
    updatetime bigint NOT NULL
)
WITH (orientation=row, compression=no, redistribute_version=1, storage_type=ustore, toast.storage_type=ustore);


ALTER TABLE db_newsql_movie.t_ucs_content_back_track_task OWNER TO gaussdb;

--
-- Name: t_ucp_as_attachment_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_as_attachment
    ADD CONSTRAINT t_ucp_as_attachment_pkey PRIMARY KEY  (objectid, fileid) WITH (storage_type=ustore);


--
-- Name: t_ucp_audit_mode_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_audit_mode
    ADD CONSTRAINT t_ucp_audit_mode_pkey PRIMARY KEY  (auditid) WITH (storage_type=ustore);


--
-- Name: t_ucp_comment_audit_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_comment_audit
    ADD CONSTRAINT t_ucp_comment_audit_pkey PRIMARY KEY  (commentid) WITH (storage_type=ustore);


--
-- Name: t_ucp_comment_backup_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_comment_backup
    ADD CONSTRAINT t_ucp_comment_backup_pkey PRIMARY KEY  (commentid, expiretime) WITH (storage_type=ustore);


--
-- Name: t_ucp_comment_content_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_comment_content
    ADD CONSTRAINT t_ucp_comment_content_pkey PRIMARY KEY  (contentid, appid, hc, projectid, scenes) WITH (storage_type=ustore);


--
-- Name: t_ucp_comment_offline_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_comment_offline
    ADD CONSTRAINT t_ucp_comment_offline_pkey PRIMARY KEY  (commentid) WITH (storage_type=ustore);


--
-- Name: t_ucp_comment_online_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_comment_online
    ADD CONSTRAINT t_ucp_comment_online_pkey PRIMARY KEY  (commentid) WITH (storage_type=ustore);


--
-- Name: t_ucp_comment_wonderful_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_comment_wonderful
    ADD CONSTRAINT t_ucp_comment_wonderful_pkey PRIMARY KEY  (commentid) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_audit_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_audit
    ADD CONSTRAINT t_ucp_danmu_audit_pkey PRIMARY KEY  (danmuid) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_backup_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_backup
    ADD CONSTRAINT t_ucp_danmu_backup_pkey PRIMARY KEY  (expiretime, danmuid) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_content_clips_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_content_clips
    ADD CONSTRAINT t_ucp_danmu_content_clips_pkey PRIMARY KEY  (danmukey) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_display_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_display
    ADD CONSTRAINT t_ucp_danmu_display_pkey PRIMARY KEY  (danmukey) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_live_audit_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_live_audit
    ADD CONSTRAINT t_ucp_danmu_live_audit_pkey PRIMARY KEY  (danmuid) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_live_offline_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_live_offline
    ADD CONSTRAINT t_ucp_danmu_live_offline_pkey PRIMARY KEY  (roomid, danmuid) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_live_online_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_live_online
    ADD CONSTRAINT t_ucp_danmu_live_online_pkey PRIMARY KEY  (roomid, danmuid) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_offline_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_offline
    ADD CONSTRAINT t_ucp_danmu_offline_pkey PRIMARY KEY  (danmukey, danmuid) WITH (storage_type=ustore);


--
-- Name: t_ucp_danmu_online_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_danmu_online
    ADD CONSTRAINT t_ucp_danmu_online_pkey PRIMARY KEY  (danmukey, danmuid) WITH (storage_type=ustore);


--
-- Name: t_ucp_event_audit_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_event_audit
    ADD CONSTRAINT t_ucp_event_audit_pkey PRIMARY KEY  (shauserid, createtime) WITH (storage_type=ustore);


--
-- Name: t_ucp_gs_group_user_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_gs_group_user
    ADD CONSTRAINT t_ucp_gs_group_user_pkey PRIMARY KEY  (groupid, shauserid) WITH (storage_type=ustore);


--
-- Name: t_ucp_id_mapping_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_id_mapping
    ADD CONSTRAINT t_ucp_id_mapping_pkey PRIMARY KEY  (outerid) WITH (storage_type=ustore);


--
-- Name: t_ucp_is_sign_in_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_is_sign_in
    ADD CONSTRAINT t_ucp_is_sign_in_pkey PRIMARY KEY  (shauserid, objectid) WITH (storage_type=ustore);


--
-- Name: t_ucp_is_user_like_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_is_user_like
    ADD CONSTRAINT t_ucp_is_user_like_pkey PRIMARY KEY  (shauserid, objectid) WITH (storage_type=ustore);


--
-- Name: t_ucp_is_user_report_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_is_user_report
    ADD CONSTRAINT t_ucp_is_user_report_pkey PRIMARY KEY  (objectid, shauserid) WITH (storage_type=ustore);


--
-- Name: t_ucp_is_voter_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_is_voter
    ADD CONSTRAINT t_ucp_is_voter_pkey PRIMARY KEY  (shauserid, objectid) WITH (storage_type=ustore);


--
-- Name: t_ucp_liveroom_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_liveroom
    ADD CONSTRAINT t_ucp_liveroom_pkey PRIMARY KEY  (roomid) WITH (storage_type=ustore);


--
-- Name: t_ucp_moment_data_count_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_moment_data_count
    ADD CONSTRAINT t_ucp_moment_data_count_pkey PRIMARY KEY  (count_time) WITH (storage_type=ustore);


--
-- Name: t_ucp_reply_backup_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_reply_backup
    ADD CONSTRAINT t_ucp_reply_backup_pkey PRIMARY KEY  (replyid, expiretime) WITH (storage_type=ustore);


--
-- Name: t_ucp_reply_offline_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_reply_offline
    ADD CONSTRAINT t_ucp_reply_offline_pkey PRIMARY KEY  (replyid) WITH (storage_type=ustore);


--
-- Name: t_ucp_reply_online_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_reply_online
    ADD CONSTRAINT t_ucp_reply_online_pkey PRIMARY KEY  (replyid) WITH (storage_type=ustore);


--
-- Name: t_ucp_reply_risk_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_reply_risk
    ADD CONSTRAINT t_ucp_reply_risk_pkey PRIMARY KEY  (replyid) WITH (storage_type=ustore);


--
-- Name: t_ucp_toast_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_toast
    ADD CONSTRAINT t_ucp_toast_pkey PRIMARY KEY  (toastid) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_content_detail_backup_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_content_detail_backup
    ADD CONSTRAINT t_ucp_ucs_content_detail_backup_pkey PRIMARY KEY  (contentid) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_content_detail_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_content_detail
    ADD CONSTRAINT t_ucp_ucs_content_detail_pkey PRIMARY KEY  (contentid) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_content_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_content
    ADD CONSTRAINT t_ucp_ucs_content_pkey PRIMARY KEY  (content_id) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_content_tag_relation_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_content_tag_relation
    ADD CONSTRAINT t_ucp_ucs_content_tag_relation_pkey PRIMARY KEY  (content_id, tag, create_time) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_mute_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_mute
    ADD CONSTRAINT t_ucp_ucs_mute_pkey PRIMARY KEY  (roomid, shauserid) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_topic_post_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_topic_post
    ADD CONSTRAINT t_ucp_ucs_topic_post_pkey PRIMARY KEY  (topic_id, post_id) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_user_content_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_user_content
    ADD CONSTRAINT t_ucp_ucs_user_content_pkey PRIMARY KEY  (contentid, shauserid) WITH (storage_type=ustore);


--
-- Name: t_ucp_ucs_user_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_ucs_user
    ADD CONSTRAINT t_ucp_ucs_user_pkey PRIMARY KEY  (shauserid) WITH (storage_type=ustore);


--
-- Name: t_ucp_us_user_group_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_us_user_group
    ADD CONSTRAINT t_ucp_us_user_group_pkey PRIMARY KEY  (groupid, shauserid) WITH (storage_type=ustore);


--
-- Name: t_ucp_us_user_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_us_user
    ADD CONSTRAINT t_ucp_us_user_pkey PRIMARY KEY  (shauserid, appid, hc, projectid) WITH (storage_type=ustore);


--
-- Name: t_ucp_us_user_relation_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_us_user_relation
    ADD CONSTRAINT t_ucp_us_user_relation_pkey PRIMARY KEY  (shauserid, relationtype, shatargetuserid, appid, hc, projectid) WITH (storage_type=ustore);


--
-- Name: t_ucp_user_collect_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_user_collect
    ADD CONSTRAINT t_ucp_user_collect_pkey PRIMARY KEY  (shauserid, objectid, favoriteid) WITH (storage_type=ustore);


--
-- Name: t_ucp_user_comment_count_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_user_comment_count
    ADD CONSTRAINT t_ucp_user_comment_count_pkey PRIMARY KEY  (shauserid, contentid, status) WITH (storage_type=ustore);


--
-- Name: t_ucp_user_comment_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_user_comment
    ADD CONSTRAINT t_ucp_user_comment_pkey PRIMARY KEY  (shauserid, commentid) WITH (storage_type=ustore);


--
-- Name: t_ucp_user_footprints_detail_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_user_footprints_detail
    ADD CONSTRAINT t_ucp_user_footprints_detail_pkey PRIMARY KEY  (shauserid, objectid) WITH (storage_type=ustore);


--
-- Name: t_ucp_user_footprints_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_user_footprints
    ADD CONSTRAINT t_ucp_user_footprints_pkey PRIMARY KEY  (shauserid, objectid) WITH (storage_type=ustore);


--
-- Name: t_ucp_user_reply_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_user_reply
    ADD CONSTRAINT t_ucp_user_reply_pkey PRIMARY KEY  (shauserid, replyid) WITH (storage_type=ustore);


--
-- Name: t_ucp_worker_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucp_worker
    ADD CONSTRAINT t_ucp_worker_pkey PRIMARY KEY  (datacenter, serverip) WITH (storage_type=ustore);


--
-- Name: t_ucs_comment_back_track_result_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucs_comment_back_track_result
    ADD CONSTRAINT t_ucs_comment_back_track_result_pkey PRIMARY KEY  (taskid, clipid) WITH (storage_type=ustore);


--
-- Name: t_ucs_comment_back_track_task_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucs_comment_back_track_task
    ADD CONSTRAINT t_ucs_comment_back_track_task_pkey PRIMARY KEY  (taskid) WITH (storage_type=ustore);


--
-- Name: t_ucs_content_back_track_result_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucs_content_back_track_result
    ADD CONSTRAINT t_ucs_content_back_track_result_pkey PRIMARY KEY  (taskid, clipid) WITH (storage_type=ustore);


--
-- Name: t_ucs_content_back_track_task_pkey; Type: CONSTRAINT; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

ALTER TABLE t_ucs_content_back_track_task
    ADD CONSTRAINT t_ucs_content_back_track_task_pkey PRIMARY KEY  (taskid) WITH (storage_type=ustore);


--
-- Name: idx_comment_audit_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_comment_audit_createtime ON t_ucp_comment_audit USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentaudit_mentionscommentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentaudit_mentionscommentid ON t_ucp_comment_audit USING ubtree (mentionscommentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentaudit_mentionscommentid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentaudit_mentionscommentid_createtime ON t_ucp_comment_audit USING ubtree (mentionscommentid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentbacktrack_taskid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentbacktrack_taskid_createtime ON t_ucs_comment_back_track_result USING ubtree (taskid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentoffline_contentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentoffline_contentid ON t_ucp_comment_offline USING ubtree (contentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentoffline_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentoffline_createtime ON t_ucp_comment_offline USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentoffline_mentionscommentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentoffline_mentionscommentid ON t_ucp_comment_offline USING ubtree (mentionscommentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentoffline_mentionscommentid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentoffline_mentionscommentid_createtime ON t_ucp_comment_offline USING ubtree (mentionscommentid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentoffline_mentionsshauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentoffline_mentionsshauserid ON t_ucp_comment_offline USING ubtree (mentionsshauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentoffline_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentoffline_shauserid ON t_ucp_comment_offline USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentoffline_shauserid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentoffline_shauserid_createtime ON t_ucp_comment_offline USING ubtree (shauserid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_contentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_contentid ON t_ucp_comment_online USING ubtree (contentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_contentid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_contentid_createtime ON t_ucp_comment_online USING ubtree (contentid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_createtime ON t_ucp_comment_online USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_mentionscommentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_mentionscommentid ON t_ucp_comment_online USING ubtree (mentionscommentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_mentionscommentid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_mentionscommentid_createtime ON t_ucp_comment_online USING ubtree (mentionscommentid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_mentionsshauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_mentionsshauserid ON t_ucp_comment_online USING ubtree (mentionsshauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_shauserid ON t_ucp_comment_online USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_shauserid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_shauserid_createtime ON t_ucp_comment_online USING ubtree (shauserid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentonline_wonderfulcreatetime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentonline_wonderfulcreatetime ON t_ucp_comment_online USING ubtree (wonderfulcreatetime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_commentwonderful_contentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_commentwonderful_contentid ON t_ucp_comment_wonderful USING ubtree (contentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_contentbacktrack_taskid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_contentbacktrack_taskid_createtime ON t_ucs_content_back_track_result USING ubtree (taskid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmuaudit_contentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmuaudit_contentid ON t_ucp_danmu_audit USING ubtree (contentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmuaudit_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmuaudit_createtime ON t_ucp_danmu_audit USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmuaudit_danmuid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmuaudit_danmuid ON t_ucp_danmu_audit USING ubtree (danmuid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmubackup_danmukey; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmubackup_danmukey ON t_ucp_danmu_backup USING ubtree (danmukey) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmubackup_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmubackup_shauserid ON t_ucp_danmu_backup USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmuoffline_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmuoffline_createtime ON t_ucp_danmu_offline USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmuoffline_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmuoffline_shauserid ON t_ucp_danmu_offline USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmuonline_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmuonline_createtime ON t_ucp_danmu_online USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_danmuonline_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_danmuonline_shauserid ON t_ucp_danmu_online USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_livedanmu_offline_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_livedanmu_offline_createtime ON t_ucp_danmu_live_offline USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_livedanmu_offline_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_livedanmu_offline_shauserid ON t_ucp_danmu_live_offline USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_livedanmu_online_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_livedanmu_online_createtime ON t_ucp_danmu_live_online USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_livedanmu_online_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_livedanmu_online_shauserid ON t_ucp_danmu_live_online USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_mute_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_mute_createtime ON t_ucp_ucs_mute USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_offline_danmu_id; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_offline_danmu_id ON t_ucp_danmu_offline USING ubtree (danmuid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_online_danmu_id; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_online_danmu_id ON t_ucp_danmu_online USING ubtree (danmuid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_reply_risk_atreplyid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_reply_risk_atreplyid_createtime ON t_ucp_reply_risk USING ubtree (atreplyid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_reply_risk_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_reply_risk_createtime ON t_ucp_reply_risk USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyoffline_commentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyoffline_commentid ON t_ucp_reply_offline USING ubtree (commentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyoffline_contentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyoffline_contentid ON t_ucp_reply_offline USING ubtree (contentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyoffline_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyoffline_createtime ON t_ucp_reply_offline USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyoffline_mentionsreplyid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyoffline_mentionsreplyid_createtime ON t_ucp_reply_offline USING ubtree (mentionsreplyid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyoffline_mentionsshauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyoffline_mentionsshauserid ON t_ucp_reply_offline USING ubtree (mentionsshauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyoffline_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyoffline_shauserid ON t_ucp_reply_offline USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyoffline_shauserid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyoffline_shauserid_createtime ON t_ucp_reply_offline USING ubtree (shauserid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyonline_commentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyonline_commentid ON t_ucp_reply_online USING ubtree (commentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyonline_contentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyonline_contentid ON t_ucp_reply_online USING ubtree (contentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyonline_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyonline_createtime ON t_ucp_reply_online USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyonline_mentionsreplyid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyonline_mentionsreplyid_createtime ON t_ucp_reply_online USING ubtree (mentionsreplyid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyonline_mentionsshauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyonline_mentionsshauserid ON t_ucp_reply_online USING ubtree (mentionsshauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyonline_shauserid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyonline_shauserid ON t_ucp_reply_online USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_replyonline_shauserid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_replyonline_shauserid_createtime ON t_ucp_reply_online USING ubtree (shauserid, createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_scope_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_scope_createtime ON t_ucp_ucs_content_tag_relation USING ubtree (scope, create_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_scope_footprints_detail_shauserid_updatetime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_scope_footprints_detail_shauserid_updatetime ON t_ucp_user_footprints_detail USING ubtree (shauserid, updatetime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_scope_footprints_shauserid_updatetime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_scope_footprints_shauserid_updatetime ON t_ucp_user_footprints USING ubtree (shauserid, updatetime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_scope_tag_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_scope_tag_createtime ON t_ucp_ucs_content_tag_relation USING ubtree (scope, tag, create_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_signin_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_signin_createtime ON t_ucp_is_sign_in USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_topic_post_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_topic_post_createtime ON t_ucp_ucs_topic_post USING ubtree (create_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_topic_post_postid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_topic_post_postid ON t_ucp_ucs_topic_post USING ubtree (post_id) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_topic_post_updatetime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_topic_post_updatetime ON t_ucp_ucs_topic_post USING ubtree (update_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucp_commnet_backup_expiretime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucp_commnet_backup_expiretime ON t_ucp_comment_backup USING ubtree (expiretime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucp_event_audit_create_time; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucp_event_audit_create_time ON t_ucp_event_audit USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucp_reply_backup_expiretime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucp_reply_backup_expiretime ON t_ucp_reply_backup USING ubtree (expiretime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_comment_sha_user_id; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_comment_sha_user_id ON t_ucp_comment_audit USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_commentscount; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_commentscount ON t_ucp_ucs_content USING ubtree (comments_count) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_createtime ON t_ucp_ucs_content USING ubtree (create_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_groupid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_groupid_createtime ON t_ucp_ucs_content USING ubtree (group_id, create_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_hc_projectid_type_status_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_hc_projectid_type_status_createtime ON t_ucp_ucs_content USING ubtree (hc, project_id, scenes, type, status, create_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_likescount; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_likescount ON t_ucp_ucs_content USING ubtree (likes_count) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_reportscount; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_reportscount ON t_ucp_ucs_content USING ubtree (reports_count) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_shauserid_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_shauserid_createtime ON t_ucp_ucs_content USING ubtree (sha_user_id, create_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_shauserid_updatetime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_shauserid_updatetime ON t_ucp_ucs_content USING ubtree (sha_user_id, update_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_content_updatetime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_content_updatetime ON t_ucp_ucs_content USING ubtree (update_time) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_danmu_create_time; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_danmu_create_time ON t_ucp_danmu_live_audit USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_danmu_roomid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_danmu_roomid ON t_ucp_danmu_live_audit USING ubtree (roomid, danmuid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_danmu_sha_user_id; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_danmu_sha_user_id ON t_ucp_danmu_live_audit USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_ucs_reply_sha_user_id; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_ucs_reply_sha_user_id ON t_ucp_reply_risk USING ubtree (shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_usercomment_commentid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_usercomment_commentid ON t_ucp_user_comment USING ubtree (commentid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_usercomment_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_usercomment_createtime ON t_ucp_user_comment USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_usergroup_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_usergroup_createtime ON t_ucp_us_user_group USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_userlike_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_userlike_createtime ON t_ucp_is_user_like USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_userlike_shauserid_creattime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_userlike_shauserid_creattime ON t_ucp_is_user_like USING ubtree (shauserid, createtime DESC) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_userlike_shauserid_objecttype; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_userlike_shauserid_objecttype ON t_ucp_is_user_like USING ubtree (shauserid, objecttype) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_userrelation_shatargetuserid_master; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_userrelation_shatargetuserid_master ON t_ucp_us_user_relation USING ubtree (shatargetuserid, relationtype, shauserid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_userreply_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_userreply_createtime ON t_ucp_user_reply USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_userreport_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_userreport_createtime ON t_ucp_is_user_report USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_userreport_objecttype_level; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_userreport_objecttype_level ON t_ucp_is_user_report USING ubtree (objecttype, level) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_voter_createtime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_voter_createtime ON t_ucp_is_voter USING ubtree (createtime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: idx_voter_objectid; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX idx_voter_objectid ON t_ucp_is_voter USING ubtree (objectid) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- Name: t_ucp_user_collect_updatetime; Type: INDEX; Schema: db_newsql_movie; Owner: gaussdb; Tablespace: 
--

CREATE INDEX t_ucp_user_collect_updatetime ON t_ucp_user_collect USING ubtree (updatetime) WITH (storage_type=ustore) TABLESPACE pg_default;


--
-- GaussDB database dump complete
--

