--
-- openGauss database dump
--

SET statement_timeout = 0;
SET xmloption = content;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: my_table5; Type: TABLE; Schema: public; Owner: tianjikun; Tablespace: 
--

CREATE TABLE my_table5 (
    id integer NOT NULL,
    my_float double precision,
    my_double double precision,
    my_varchar2 character varying(5),
    my_timestamp timestamp without time zone,
    my_blob blob,
    my_text text
)
WITH (orientation=row, compression=no);


ALTER TABLE public.my_table5 OWNER TO tianjikun;

--
-- Name: my_table5_pkey; Type: CONSTRAINT; Schema: public; Owner: tianjikun; Tablespace: 
--

ALTER TABLE my_table5
    ADD CONSTRAINT my_table5_pkey PRIMARY KEY  (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: omm
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM omm;
GRANT CREATE,USAGE ON SCHEMA public TO omm;
GRANT USAGE ON SCHEMA public TO PUBLIC;


--
-- openGauss database dump complete
--

