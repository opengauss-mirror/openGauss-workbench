# README

Archived submission of the winning submission to [NeurIPS 2020 Black-Box Optimisation Challenge](https://bbochallenge.com/leaderboard). 