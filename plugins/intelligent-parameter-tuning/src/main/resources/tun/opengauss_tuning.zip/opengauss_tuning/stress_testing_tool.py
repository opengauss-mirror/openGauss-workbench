import argparse
import os
import sys
import time
import json

import config
import utils
from SuperWG.DWG.PressureTest.multi_thread_test_only_run_workloads_without_create_schema import \
    multi_thread_without_create_schema


class stress_testing_tool:
    def __init__(self, knobs_detail, id, db):
        self.port = config.port
        self.host = config.host
        self.user = config.user
        self.password = config.password
        self.dbname = config.db
        self.tables = config.tables
        self.table_size = config.table_size
        self.runing_time = int(config.runing_time)
        self.warm_up_time = int(config.warm_up_time)
        self.omm_password = config.omm_password
        self.threads = config.threads
        self.logger = utils.get_logger('log/benchmark_log/{}.log'.format(config.tuning_id))
        self.benchmark = config.benchmark
        self.knobs_detail = knobs_detail
        self.id = id
        self.db = db

    def handle_HORD_config(self, config):
        temp_config = {}

        for index, key in enumerate(self.knobs_detail.keys()):
            temp_config[key] = int(config[index])

        y = self.test_config(temp_config)
        return y

    def handle_HEBO_config(self, config):
        temp_config = {}
        config = config.reset_index(drop=True)

        for key in self.knobs_detail.keys():
            temp_config[key] = int(config.loc[0, key])
        try:
            y = self.test_config(temp_config)
        except:
            # 恢复数据库的数据目录
            self.logger.warn('配置没生效， 重新恢复数据库状态')
            if config.backup:
               self.db.restore_backup_data()
            y = 0
        return y

    def handle_SMAC_config(self, config):
        temp_config = {}
        for key in self.knobs_detail.keys():
            temp_config[key] = config[key]

        y = self.test_config(temp_config, enable_restore_data=None)
        return y

    def handle_CPSGB_config(self, config, seed=0, enable_restore_data=None):
        temp_config = {}
        config = config.reset_index(drop=True)

        for key in self.knobs_detail.keys():
            temp_config[key] = int(config.loc[0, key])
        try:
            y = self.test_config(temp_config, enable_restore_data=enable_restore_data)
        except:
            # 恢复数据库的数据目录
            self.logger.warn('配置没生效， 重新恢复数据库状态')
            if config.backup:
               self.db.restore_backup_data()
            y = 0
        return y

    def test_config(self, config_knob, enable_restore_data=None):
        temp_config = {}
        for key in config_knob.keys():
            if self.knobs_detail[key]['vartype'] == 'integer':
                if float(self.knobs_detail[key]['max_val']) > sys.maxsize:
                    temp_config[key] = config_knob[key] * 1000000
                else:
                    temp_config[key] = config_knob[key]
            elif self.knobs_detail[key]['vartype'] == 'enum':
                temp_config[key] = self.knobs_detail[key]['enumvals'][config_knob[key]]

        flag_change_knob_success = self.db.change_knob(temp_config, enable_restore_data=enable_restore_data)

        if flag_change_knob_success:
            log_file = 'log/benchmark_log/'.format(self.id) + '{}.log'.format(int(time.time()))

            print('Stress Testing...')
            t0_stt = time.time()
            if self.benchmark == 'sysbench':
                y = self.test_by_sysbench(log_file)
            elif self.benchmark == 'tpcc':
                y = self.test_by_tpcc(log_file)
            else:
                if config.taskset:
                    command = "taskset -c " + config.pt_cpus + " " + 'python3 run_dwg.py --id={}'.format(self.id)
                    out = os.popen(command)
                    res = out.read()
                    y = float(res.split("=")[1].strip())
                else:
                    y = self.test_by_dwg(log_file)
            t1_stt = time.time()
            print(f'Stress testing timing: {t1_stt - t0_stt}')

            f = open('./history_results/{}'.format(self.id), 'a')
            temp_config['qps'] = y
            f.writelines(json.dumps(temp_config) + '\n')
            f.close()
        else:
            y = 0

        return y

    def test_by_sysbench(self, log_file):
        command_warm = 'sysbench --db-driver=pgsql --threads={} --pgsql-host={} --pgsql-port={} --pgsql-user={} --pgsql-password={} --pgsql-db={} --tables={} --table-size={} --time={} {} run'.format(
            self.threads,
            self.host,
            self.port,
            self.user,
            self.password,
            self.dbname,
            self.tables,
            self.table_size,
            self.warm_up_time,
            config.mode
        )

        command_run = 'sysbench --db-driver=pgsql --threads={} --pgsql-host={} --pgsql-port={} --pgsql-user={} --pgsql-password={} --pgsql-db={} --tables={} --table-size={} --time={} {} run'.format(
            self.threads,
            self.host,
            self.port,
            self.user,
            self.password,
            self.dbname,
            self.tables,
            self.table_size,
            self.runing_time,
            config.mode
        )

        if config.taskset:
            command_warm = "taskset -c " + config.pt_cpus + " " + command_warm
            command_run = "taskset -c " + config.pt_cpus + " " + command_run

        #ssh = self.db.get_ssh()
        print('run sysbench...', command_run)
        if self.warm_up_time > 0:
            #stdin, stdout, stderr = ssh.exec_command(command_warm)
            result = os.popen(command_warm).read()
        #stdin, stdout, stderr = ssh.exec_command(command_run)
        result = os.popen(command_run).read()
        #res = stdout.read().decode('utf-8')
        res = result
        print('run sysbench over...')

        lines = res.split('\n')
        for line in lines:
            if 'queries:' in line:
                qps = float(line.split()[2].split('(')[1])
                return qps
        self.logger.info('sysbench run error: \n')
        self.logger.info(res)
        return -1

    def test_by_tpcc(self, log_file):
        command = '/usr/local/benchmarksql-5.0/run/runBenchmark.sh props.pg > {}'.format(log_file)
        state = os.system(command)

        if state == 0:
            self.logger.info('tpcc running success')
        else:
            self.logger.info('tpcc running error')

        with open(log_file) as f:
            lines = f.readlines()
        for line in lines:
            if 'Measured tpmTOTAL' in line:
                qps = float(line.split()[9])

        return -qps

    def test_by_dwg(self, log_file):
        print("run dwg...")
        parser = argparse.ArgumentParser()
        parser.add_argument('--database_name', type=str, default=config.db)
        parser.add_argument('--user_name', type=str, default=config.user)
        parser.add_argument('--password', type=str, default=config.password)
        parser.add_argument('--host', type=str, default=config.host)
        parser.add_argument('--port', type=int, default=config.port)
        parser.add_argument('--n_jobs', type=int, default=config.threads)
        parser.add_argument('--workload_path', default=config.workload)
        parser.add_argument('--id', default=self.id)
        args = parser.parse_args()

        mh = multi_thread_without_create_schema(args)
        mh.data_pre()
        try:
            qps = mh.run()
        except Exception as e:
            self.logger.warn('压测失败,恢复数据库配置',e)
            self.db.restore()
            qps = -1
        print("dwg over...")
        return qps
