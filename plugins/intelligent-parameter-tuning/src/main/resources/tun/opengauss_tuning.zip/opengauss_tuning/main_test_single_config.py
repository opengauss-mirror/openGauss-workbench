import logging

logging.disable(logging.DEBUG)

import sys
import os
import numpy as np
import pandas as pd
from pathlib import Path
import time
import json

sys.path.append('/data/tuning/opengauss_tuning/')
os.chdir('/data/tuning/opengauss_tuning/')

import config
import utils
from Database import Database
from knob_ranking.shap_final import knob_selection
from knowledge_transfer import update_knowledge, mapping
from tuner_cpsgb import tuner
from utils import analyse_result, save_result

def get_init_sample_df(init_runhistory_dir):
    init_runhistory_file = Path(init_runhistory_dir, 'runhistory.json')
    with open(init_runhistory_file, 'r') as file:
        init_runhistory = json.load(file)
    init_X = pd.DataFrame([elem for key, elem in init_runhistory['configs'].items()])
    init_y = np.array([elem[4] for elem in init_runhistory['data']]).reshape(-1, 1)
    init_walltime = np.array([elem[5] for elem in init_runhistory['data']]).reshape(-1, 1)
    return init_X, init_y, init_walltime

if __name__ == '__main__':

    # 查询系统内存
    out = os.popen('free -g')
    res = out.readlines()[1].split()[1]
    config.memory = int(res) + 1

    # 初始化数据库实例, 创建数据库连接, 修改参数, 查询数据库状态, 重启等操作
    db = Database()

    # 初始化调优模型
    tuner_instance = tuner(db, exp_label='cpsgb_test4')

    # 获取调优历史数据
    dir_runhistory = os.path.join("/data/tuning/opengauss_tuning/smac3_output", 'cpsgb_test3', 'CPSGB', '0')
    print(dir_runhistory)
    init_X, init_y, _ = get_init_sample_df(dir_runhistory)
    np.where(init_y==init_y.min())

    init_X.iloc[6,]
    init_y[6]

    # 测试
    # rec_x = init_X.iloc[[6],]
    rec_x = init_X.iloc[[6],]
    qps = tuner_instance.stt.handle_CPSGB_config(rec_x, seed=0, enable_restore_data=True)
    print(qps)




