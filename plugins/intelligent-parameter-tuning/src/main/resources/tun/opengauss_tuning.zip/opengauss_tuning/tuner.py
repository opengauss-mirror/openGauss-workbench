import torch

import utils
import config
from pyDOE import lhs
import numpy as np
from hebo.design_space.design_space import DesignSpace
from hebo.optimizers.hebo import HEBO
import sys
import time
from datetime import datetime
from stress_testing_tool import stress_testing_tool
from data_process import data_process
from Database import Database

class tuner:
    def __init__(self, db):
        self.db = Database()
        self.method = config.method
        self.iteration = config.iteration
        self.database_name = config.db
        self.sampling_number = config.sampling_number
        # 调优所用到的参数配置
        self.knobs_detail = utils.get_knobs_detail(config.knobs_file)
        self.knobs_number = len(self.knobs_detail)
        self.benchmark = config.benchmark
        # 每次调优设置一个时间戳, 调优数据文件均以时间戳命名, 并用于负载映射的键
        self.id = int(time.time())
        self.tuning_id = config.tuning_id
        self.db_connector = data_process('db/tuning.db')
        self.logger = utils.get_logger('log/tune_log/{}.log'.format(self.tuning_id))
        # 实例化压测工具
        self.stt = stress_testing_tool(self.knobs_detail, self.id, db)

    def tune(self):
        # HEBO分为两个阶段, 随机采样LHS, 模型推荐HEBO
        if self.method == 'HEBO':
            self.LHS()
            # HEBO利用LHS所采样的数据进行初始化
            self.HEBO(self.id)

    def LHS(self):
        if self.sampling_number == 0:
            return

        lb, ub, enum_knobs = [], [], []
        # 初始化采样空间
        for index, knob in enumerate(self.knobs_detail):
            if self.knobs_detail[knob]['vartype'] == 'enum':
                lb.append(0)
                ub.append(len(self.knobs_detail[knob]['enumvals']) - 1)
                enum_knobs.append([index, knob])
            else:
                lb.append(int(self.knobs_detail[knob]['min_val']))
                ub.append(int(self.knobs_detail[knob]['max_val']))

        lb = np.array(lb)
        ub = np.array(ub)
        points_dict = []
        points = (lb + (ub - lb) * lhs(self.knobs_number, self.sampling_number)).astype(int).tolist()
        for point in points:
            temp = {}
            for index, knob in enumerate(self.knobs_detail):
                if index == self.knobs_number:
                    break
                temp[knob] = point[index]

            points_dict.append(temp)
        # 对每个采样点进行压测
        for index, point in enumerate(points_dict):
            print('random sampling epoch {}\t total {}'.format(index + 1, self.sampling_number))
            qps = self.stt.test_config(point)
            self.logger.info(str(self.id) + '\trandom ' + str(index + 1) + '\t' + str(point) + "\tqps = " + str(qps) + '\n')
            init_qps_formatted = "{:.2f}".format(qps)  # 保留小数点后两位
            self.db_connector.insert_data(str(self.tuning_id), str(index + 1), '随机采样', datetime.now().strftime("%Y-%m-%d %H:%M:%S"), str(point), str(init_qps_formatted))
            print('random {}: qps = {}'.format(index + 1, qps))

    def HEBO(self, id):
        # 导入采样的调优数据
        data = utils.load_sampling_data('./history_results/{}'.format(id))
        data = data.dropna(axis=0, how='any')

        params = []

        # 初始化样本空间
        for name in self.knobs_detail.keys():
            if self.knobs_detail[name]['vartype'] == "integer":
                if int(self.knobs_detail[name]['max_val']) > sys.maxsize:
                    params.append({'name': name, 'type': 'int', 'lb': int(self.knobs_detail[name]['min_val']) / 1000000,
                                   'ub': int(self.knobs_detail[name]['max_val']) / 1000000})
                else:
                    params.append({'name': name, 'type': 'int', 'lb': int(self.knobs_detail[name]['min_val']),
                                   'ub': int(self.knobs_detail[name]['max_val'])})
            elif self.knobs_detail[name]['vartype'] == "enumvals":
                params.append(
                    {'name': name, 'type': 'int', 'lb': 0, 'ub': len(self.knobs_detail[name]['enumvals']) - 1})

        space = DesignSpace().parse(params)

        hebo_batch = HEBO(space)
        # 由于HEBO的优化目标是最小值, 而qps优化目标为最大值, 故进行取相反数操作
        hebo_batch.observe(data[data.columns[:-1]], -np.array(data['qps']).reshape(-1, 1))

        for step in range(self.iteration):
            print('model suggest epoch {}\t total {}'.format(step + 1, self.iteration))
            # HEBO所推荐的样本点
            rec_x = hebo_batch.suggest(n_suggestions=1)

            tmp = rec_x
            temp_config = {}
            tmp = tmp.reset_index(drop=True)
            for key in self.knobs_detail.keys():
                if config.online and not config.restart_when_online and self.db.knobs[key]['restart']:
                    continue
                temp_config[key] = int(tmp.loc[0, key])
            # 对样本点进行压测
            qps = self.stt.handle_HEBO_config(rec_x)
            # 将新的样本加载入模型, 进行优化
            hebo_batch.observe(rec_x, -np.array([[qps]]))
            self.logger.info(str(self.tuning_id) + '\tsuggest ' + str(step + 1) + '\t' + str(temp_config) + "\tqps = " + str(qps) + '\n')
            init_qps_formatted = "{:.2f}".format(qps)  # 保留小数点后两位
            self.db_connector.insert_data(str(self.tuning_id), str(step + 1), '模型推荐', datetime.now().strftime("%Y-%m-%d %H:%M:%S"), str(temp_config), str(init_qps_formatted))
            print('suggest {}: qps = {}'.format(step + 1, qps))
