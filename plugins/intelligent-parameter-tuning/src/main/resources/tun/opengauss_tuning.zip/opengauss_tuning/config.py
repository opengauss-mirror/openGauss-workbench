# 集群id
tuning_id = 1802593592658169856
# 调优配置
# 随机采样次数
sampling_number = 1
# 模型推荐次数
iteration = 2
# 调优方式, 在线True, 离线False
online = False
# 是否进行微调, iteration为微调次数
finetune = True
# 在线调优是否允许重启
restart_when_online = False
# 是否绑定核
taskset = False
# 数据库是否安装在沙箱环境
chroot = False
# 数据库是否是分布式
distributed = False
# 分布式环境下DN节点的端口号
dist_dn_port = 40010
# 如果绑核, 绑哪些核, 0即绑定到cpu0, 0-3即绑定在cpu0、1、3
# 数据库绑定核心
db_cpus = "4-15"
# 压测工具绑定核心
pt_cpus = "0-3"
# 数据库待调整的配置参数文件
knobs_file = 'knobs_config/knobs-43.json'
# 进行重要性排名后, 选取的配置参数的数量
ranked_knobs_number = 15
method = 'HEBO'
log_path = 'log'
final_results = 'final_results'
knowledge = 'knowledge.json'
init_param = 'init_param'

# 数据库配置
host = 'XXX.XXX.XXX.XXX'
root_password = 'XXXXXXXX'
os_user='omm'
omm_password = 'XXXXXXXX'
# 端口号，如果是分布式则为CN节点端口
port = 15400
db = 'dbtest'
user = 'dbuser'
password = 'dbuser@123'
# 重启数据库的等待时间, 若超时仍未启动, 则恢复数据库
time_wait = 300


# 所使用的压测工具 sysbench 或 dwg
benchmark = 'dwg'
#benchmark = 'sysbench'
# 压测线程数
threads = 128


# sysbench配置
tables = 20
table_size = 2000000
mode = 'oltp_read_write'
runing_time = 60
# 正式压测之前预热时间, 结果不计算在最终tps中
warm_up_time = 30


# dwg配置
# 需要解析的schema名称
schema_name = 'public'
# 执行gs_dump命令后在服务端保存的结果(建表语句等, 用于生成负载)
remote_cache_path = '/home/omm/test.sql'
# 执行gs_dump命令后在本地保存的结果
local_cache_path = 'workloads/schema/test.sql'
# 默认不分析本地文件
use_local = 'false'
# 生成负载的规模
sql_num = 10000
# 生成负载的读写比 read / total
read_write_ratio = 0.01
# 生成负载的其他配置信息
json_extract_result_path = 'workloads/schema/res.json'
# 生成负载的保存路径, 也是使用dwg压测所用的负载
workload = 'workloads/res.wg'
# 还原负载的SQL，将负载中insert对应的数据转为delete，在每轮压测完执行还原
workload_restore = 'workloads/restore.sql'
# 每个线程成功执行sql_num_print条sql后在控制台输出信息
sql_num_print = 500


# hardware configs
memory = 32

index_weight=1
primary_key_weight=1
averageTableNum = [1,0]
query_comparison_operator_ratio = [0,0,1,0]
table_domain_distribution = [0.5,0.5]
query_logic_predicate_num = [1,0,0]
average_aggregation_operator_num = [1,0,0]
average_query_column_num = [0,0.6,0.3,0.1]
group_by_ratio_if_read_sql = [1,0]
order_by_desc_or_asc_if_grouped = [1,0]

