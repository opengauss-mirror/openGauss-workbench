import threading
import time

import paramiko
import psycopg2

import config
import utils


class Database:
    def __init__(self):
        self.host = config.host
        self.port = config.port
        self.database = config.db
        self.user = config.user
        self.password = config.password
        self.omm_password = config.omm_password
        self.data_path = config.opengauss_node_path
        self.backup_path = config.backup_path
        self.knobs = utils.get_knobs_detail(config.knobs_file)
        self.ssh = None
        self.get_ssh()
        self.logger = utils.get_logger('log/db_log/{}.log'.format(config.tuning_id))
        self.restart_flag = False

    # 获取数据库远程连接
    def get_conn(self):
        return psycopg2.connect(database=self.database,
                                user=self.user,
                                password=self.password,
                                host=self.host,
                                port=int(self.port))

    # 获取数据库所在机器的SSH连接, 用于执行修改参数的命令, 重启数据库等
    def get_ssh(self):
        if self.ssh is None:
            self.ssh = paramiko.SSHClient()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh.connect(hostname=self.host,
                             port=22,
                             username='omm',
                             password=self.omm_password
                             )
        return self.ssh

    # 数据库重启
    def restart(self):
        self.restart_flag = False
        ssh = self.get_ssh()
        ssh.exec_command("echo 3 > /proc/sys/vm/drop_caches")
        print('系统缓存清理完毕')
        print('database restarting...')
        cmd = "gs_ctl restart -D {} -M primary".format(self.data_path)
        if config.taskset:
            cmd = "taskset -c " + config.db_cpus + " " + cmd
        _, stdout, stderr = ssh.exec_command(cmd)
        info = stdout.read().decode('utf-8')
        # self.logger.info(info)
        if info.find("started") != -1 or info.find("Success") != -1 or info.find("success") != -1:
            self.restart_flag = True
            # 连接测试
            count = 0
            while True:
                try:
                    dbc = self.get_conn()
                    self.logger.info('Connected to DB')
                    dbc.close()
                    break
                except:
                    self.logger.info(f"Retry connecting to DB: {count}")

                time.sleep(1)
                count = count + 1
                if count > config.time_wait:
                    self.restart_flag = False
                    break
        if self.restart_flag:
            print('database restart successfully')
        else:
            print('DB connection error')

    # 数据库恢复
    def restore(self):
        ssh = self.get_ssh()
        _, stdout, stderr = ssh.exec_command(
            'cp {}/postgresql_bak.conf {}/postgresql.conf'.format(self.data_path, self.data_path))
        self.restart()

    def fetch_knob(self):
        conn = self.get_conn()
        knobs = {}
        cursor = conn.cursor()
        for knob in self.knobs:
            sql = "SELECT name, setting FROM pg_settings WHERE name='{}'".format(knob)
            cursor.execute(sql)
            result = cursor.fetchall()
            for s in result:
                if self.knobs[knob]['vartype'] == 'integer' or self.knobs[knob]['vartype'] == 'int64':
                    knobs[knob] = int(s[1])
                elif self.knobs[knob]['vartype'] == 'real':
                    knobs[knob] = float(s[1])
                else:
                    knobs[knob] = s[1]
        cursor.close()
        conn.close()
        return knobs

    # 获取数据库状态信息, 机器信息等, 用于知识匹配
    def fetch_inner_metric(self):
        state_list = []
        try:
            conn = self.get_conn()
        except:
            self.restore()
            print('Restore database config')
            conn = self.get_conn()
        ssh = self.get_ssh()
        cursor = conn.cursor()

        # ['cpu_useage','memory_useage','kB_rd/s','kB_wr/s','cache_hit_rate','concurrent_users','lock_wait_count','error_rate','logical_reads_per_second','physical_reads_per_second','active_session','transactions_per_second','rows_scanned_per_second','rows_updated_per_second','rows_deleted_per_second']
        # cpu和内存占用率s
        stdin, stdout, stderr = ssh.exec_command("top -b -n 1")
        lines = stdout.readlines()
        gaussdb_line = None
        for line in lines:
            if 'gaussdb' in line:
                gaussdb_line = line
                break
        if gaussdb_line:
            columes = gaussdb_line.split()
            cpu_usage = columes[8]
            state_list.append(cpu_usage)
            mem_usage = columes[9]
            state_list.append(mem_usage)
        else:
            print("gaussdb process not found in top output.")

        # 每秒读取和写入的kB数，kB_rd/s,kB_wr/s
        stdin, stdout, stderr = ssh.exec_command("pidstat -d")
        lines = stdout.readlines()[1:]
        gaussdb_line = None
        for line in lines:
            if 'gaussdb' in line:
                gaussdb_line = line
                break
        if gaussdb_line:
            columes = gaussdb_line.split()
            kB_rd = columes[3]
            state_list.append(kB_rd)
            kB_wr = columes[4]
            state_list.append(kB_wr)
        else:
            print("gaussdb process not found in pidstat")

        # cache_hit_rate
        cache_hit_rate_sql = "select blks_hit / (blks_read + blks_hit + 0.001) " \
                             "from pg_stat_database " \
                             "where datname = '{}';".format(self.database)

        # 并发用户数量
        concurrent_users = """
        SELECT
            count(DISTINCT usename)
        AS
            concurrent_users
        FROM
            pg_stat_activity
        WHERE
            state = 'active';
        """

        # 锁等待次数
        lock = """
        SELECT
            count(*) AS lock_wait_count
        FROM
            pg_stat_activity
        WHERE
            waiting = true;
        """

        # 错误率
        error_rate = """
        SELECT
            (sum(xact_rollback) + sum(conflicts) + sum(deadlocks)) / (sum(xact_commit) + sum(xact_rollback) + sum(conflicts) + sum(deadlocks)) AS error_rate
        FROM
            pg_stat_database;
        """

        # 逻辑读/秒和物理读/秒
        read = """
        SELECT
            logical_reads / (extract(epoch from now() - stats_reset)) AS logical_reads_per_second,
            physical_reads / (extract(epoch from now() - stats_reset)) AS physical_reads_per_second
        FROM (
            SELECT
                sum(tup_returned + tup_fetched) AS logical_reads,
                sum(blks_read) AS physical_reads,
                max(stats_reset) AS stats_reset
            FROM
                pg_stat_database
            ) subquery;
        """

        # 活跃会话数量
        active_session = """
        SELECT
            count(*) AS active_session
        FROM
            pg_stat_activity;
        """

        # 每秒提交的事务数
        transactions_per_second = """
        SELECT
            total_commits / (extract(epoch from now() - max_stats_reset)) AS transactions_per_second
        FROM (
            SELECT
            sum(xact_commit) AS total_commits,
            max(stats_reset) AS max_stats_reset
        FROM
            pg_stat_database
            ) subquery;
        """

        # 扫描行、更新行和删除行
        tup = """
        SELECT
            rows_scanned / (extract(epoch from now() - max_stats_reset)) AS rows_scanned_per_second,
            rows_updated / (extract(epoch from now() - max_stats_reset)) AS rows_updated_per_second,
             rows_deleted / (extract(epoch from now() - max_stats_reset)) AS rows_deleted_per_second
        FROM (
            SELECT
            sum(tup_returned) AS rows_scanned,
            sum(tup_updated) AS rows_updated,
            sum(tup_deleted) AS rows_deleted,
            max(stats_reset) AS max_stats_reset
            FROM
             pg_stat_database
            ) subquery;
        """

        try:
            cursor.execute(cache_hit_rate_sql)
            result = cursor.fetchall()
            for s in result:
                state_list.append(float(s[0]))

            # 并发用户数量
            cursor.execute(concurrent_users)
            result = cursor.fetchall()
            state_list.append(float(result[0][0]))

            # 锁等待次数
            cursor.execute(lock)
            result = cursor.fetchall()
            state_list.append(float(result[0][0]))

            # 错误率
            cursor.execute(error_rate)
            result = cursor.fetchall()
            state_list.append(float(result[0][0]))

            # 逻辑读和物理读
            cursor.execute(read)
            result = cursor.fetchall()
            # print(result)
            for i in result[0]:
                state_list.append(float(i))

            # 活跃会话数
            cursor.execute(active_session)
            result = cursor.fetchall()
            # print(result)
            state_list.append(float(result[0][0]))

            # 每秒提交的事务
            cursor.execute(transactions_per_second)
            result = cursor.fetchall()
            # print(result)
            state_list.append(float(result[0][0]))

            # 扫描、更新、删除行
            cursor.execute(tup)
            result = cursor.fetchall()
            for i in result[0]:
                state_list.append(float(i))

            cursor.close()
            conn.close()
        except Exception as error:
            print(error)
        for i in range(len(state_list)):
            state_list[i] = float(state_list[i])
        return state_list

    def restore_backup_data(self):
        t0_restore_backup = time.time()
        ssh = self.get_ssh()
        _, stdout, stderr = ssh.exec_command('find {}'.format(config.backup_path))
        res = stdout.read()
        if len(res) == 0:
            print('数据库数据备份文件不存在')
            exit(1)
        _, stdout, stderr = ssh.exec_command('gs_ctl stop -D {}'.format(self.data_path))
        stdout_content = stdout.read()
        stderr_content = stderr.read()
        stop_result = stdout_content.decode() + stderr_content.decode()
        if ('[  OK  ]' in stop_result) or ('SUCCESS' in stop_result) or ('Success' in stop_result) or ('done' in stop_result) or ('server running' in stop_result):
            self.logger.info(stop_result)
        else:
            self.logger.error('数据库停止失败, 强制删除')
            self.logger.error(stop_result)
            from subprocess import check_output
            def get_pid(name):
                return list(map(int, check_output(["pidof", name]).split()))
            try:
                gaussdb_pids = get_pid('gaussdb')
                for pid in gaussdb_pids:
                    ssh.exec_command(f'kill -9 {pid}')
                    self.logger.error('Timeout kill gaussdb')
                self.logger.error('kill gaussdb finished')
            except:
                self.logger.error('No gaussdb running')

        print('开始恢复数据库...')
        _, stdout, stderr = ssh.exec_command('rm -rf {}/*'.format(self.data_path))
        res = stdout.read()
        _, stdout, stderr = ssh.exec_command('cp -r -f {}/* {}'.format(self.backup_path, self.data_path))
        res = stdout.read()
        print(f'数据库恢复完毕, timing: {time.time()-t0_restore_backup}')
        # self.restart()
        # print('数据库重启完毕')
        print(stdout.read().decode('utf-8'))

    # 修改配置参数
    def change_knob(self, knobs, enable_restore_data=None):
        ssh = self.get_ssh()

        # 恢复数据库的数据目录
        if enable_restore_data is None:
            if config.backup:
                self.restore_backup_data()
        else:
            if enable_restore_data:
                self.restore_backup_data()

        print('修改配置参数...', knobs)
        for knob in knobs:
            # 在线调优仅修改经过筛选的参数(无需重启, 重要的)
            if knob not in self.knobs:
                continue

            # integer
            if self.knobs[knob]['vartype'] == 'integer' or self.knobs[knob]['vartype'] == 'int64':
                val = int(knobs[knob])
            # real
            elif self.knobs[knob]['vartype'] == 'real':
                val = float(knobs[knob])
            # string, bool, enum
            else:
                val = knobs[knob]

            if config.online:
                _, stdout, stderr = ssh.exec_command('gs_guc reload -c "{}={}" -D {}'.format(knob, val, self.data_path))
            else:
                _, stdout, stderr = ssh.exec_command('gs_guc set -c "{}={}" -D {}'.format(knob, val, self.data_path))
            info = stdout.read().decode('utf-8')
            if info.find("Success") == -1:
                self.logger.info(info)

        # 离线调优重启数据库, 若失败则还原postgresql.conf
        flag_change_knob_success = False
        if not config.online:
            t = threading.Thread(target=self.restart)
            t.setDaemon(True)
            t.start()
            # 在time_wait时间内若重启失败, 则认为由于配置参数取值不合理导致数据库故障, 故恢复重置
            t.join(timeout=config.time_wait)
            if not self.restart_flag:
                self.restore()
                print('restore database config')
            else:
                flag_change_knob_success = True
        else:
            flag_change_knob_success = True

        return flag_change_knob_success

        # return self.restart_flag
