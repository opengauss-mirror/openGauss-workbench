import threading
import time

import paramiko
import psycopg2

import config
import utils
import os
import json


class Database:
    def __init__(self):
        self.host = config.host
        self.port = config.port
        self.database = config.db
        self.user = config.user
        self.password = os.environ.get('dbPassword')
        self.omm_password = os.environ.get('installPassword')
        self.knobs = utils.get_knobs_detail(config.knobs_file)
        self.ssh = None
        self.ssh_root = None
        self.os_user=config.os_user
        self.get_ssh()
        #self.drop_cache()
        self.logger = utils.get_logger('log/db_log/{}.log'.format(config.tuning_id))
        self.restart_flag = False

    # 获取数据库远程连接
    def get_conn(self, db_port=config.port):
        return psycopg2.connect(database=self.database,
                                user=self.user,
                                password=self.password,
                                host=self.host,
                                port=db_port)

    # 获取数据库所在机器的SSH连接, 用于执行修改参数的命令, 重启数据库等
    def get_ssh(self):
        if self.ssh is None:
            self.ssh = paramiko.SSHClient()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh.connect(hostname=self.host,
                                port=22,
                                username=self.os_user,
                                password=self.omm_password
                            )
        return self.ssh

    # 清理操作系统缓存
    def drop_cache(self):
        if self.ssh_root is None:
            self.ssh_root = paramiko.SSHClient()
            self.ssh_root.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh_root.connect(hostname=self.host,
                                port=22,
                                username='root',
                                password=os.environ.get('password')
                            )
        self.ssh_root.exec_command("echo 3 > /proc/sys/vm/drop_caches")
        print('系统缓存清理完毕')

        return self.ssh_root

    # 登录沙箱
    def get_shell(self, ssh):
        # 采用invoke_shell允許執行具有依賴關係的命令
        shell = ssh.invoke_shell()
        time.sleep(10)
       
        if config.chroot:
            # 登录沙箱
            shell.send('/usr/sbin/chroot /var/chroot/ \n')
            while not shell.recv_ready():
                pass
            shell.send('source ~/gauss_env_file \n')
            time.sleep(3)
        
            output = shell.recv(9999)
            #self.logger.info(f"LOGIN sendbox: {output.decode('utf-8')}")
        
        return shell

    # 数据库重启
    def restart(self):
        self.restart_flag = False
        #ssh_root = self.drop_cache()
        
        ssh = self.get_ssh()
        shell = self.get_shell(ssh)
        print('database restarting...')    

        # 主备、分布式
        cmd = "gs_om -t restart \n"
        if config.taskset:
            cmd = "taskset -c " + config.db_cpus + " " + cmd
        shell.send(cmd)
        while not shell.recv_ready():
            pass
        time.sleep(10)
        while True:
            status_cmd = "gs_om -t status | grep cluster_state | cut -d ':' -f 2"
            _, stdout, stderr = ssh.exec_command(status_cmd)
            info = stdout.read().decode('utf-8')
            i = 0
            if info.find("Normal") != -1 or info.find("normal") != -1:
                try:
                    dbc = self.get_conn()
                    self.logger.info('Connected to DB')
                    dbc.close()
                    self.restart_flag = True
                    break
                except:
                    pass
                break
            if i > config.time_wait:
                self.logger.info(f"Failed to connect to DB")
                break
            time.sleep(1)
            i += 1
        #time.sleep(50)
        output1 = shell.recv(9999)
        info = output1.decode('utf-8')
        self.logger.info(f"DB restart: {output1.decode('utf-8')}")

        self.logger.info(info)
        
        if self.restart_flag:
            print('database restart successfully')
        else:
            print('DB connection error')
        return self.restart_flag

    # 数据库恢复
    def restore(self, knob_files=config.host):
        ssh = self.get_ssh()
        shell = self.get_shell(ssh)

        # 从配置备份文件中恢复数据库配置
        if not os.path.exists(knob_files):
            print("初始参数备份文件不存在，程序退出！")
            exit()
       
        config_file = open(knob_files, 'r')
        for line in config_file:
            knobs = json.loads(line.replace("'",'"'))
            for knob in knobs:
                cmd = 'gs_guc set -Z datanode -N all -I all -c "{}={}" \n'.format(knob, knobs[knob])
                shell.send(cmd + ' \n')
        output = shell.recv(2000)
        info = output.decode('utf-8')
        self.logger.info(f"gs_guc : {info}")
        if info.find("Success") == -1:
            self.logger.info(info)

        self.restart()

    # 获取初始配置
    def fetch_knob(self):
        dn_port = config.port
        # 如果是分布式环境，则仅针对DN节点进行优化，故只变更DN节点的参数
        if config.distributed:
            dn_port = config.dist_dn_port
        conn = self.get_conn(dn_port)
        knobs = {}
        cursor = conn.cursor()
        init_knobs = ""
        for knob in self.knobs:
            sql = "SELECT name, setting FROM pg_settings WHERE name='{}'".format(knob)
            cursor.execute(sql)
            result = cursor.fetchall()
            for s in result:
                if self.knobs[knob]['vartype'] == 'integer' or self.knobs[knob]['vartype'] == 'int64':
                    knobs[knob] = int(s[1])
                elif self.knobs[knob]['vartype'] == 'real':
                    knobs[knob] = float(s[1])
                else:
                    knobs[knob] = s[1]

        cursor.close()
        conn.close()

        # 判断初始文件是否存在，并保存初始参数到文件
        if not os.path.exists(self.host):
            with open(self.host, 'x') as file:
                file.write(str(knobs))
                print("创建初始配置文件",self.host)

        return knobs

    # 获取数据库状态信息, 机器信息等, 用于知识匹配
    def fetch_inner_metric(self):
        state_list = []
        try:
            conn = self.get_conn()
        except:
            self.restore()
            print('Restore database config')
            conn = self.get_conn()
        ssh = self.get_ssh()
        cursor = conn.cursor()

        # ['cpu_useage','memory_useage','kB_rd/s','kB_wr/s','cache_hit_rate','concurrent_users','lock_wait_count','error_rate','logical_reads_per_second','physical_reads_per_second','active_session','transactions_per_second','rows_scanned_per_second','rows_updated_per_second','rows_deleted_per_second']
        # cpu和内存占用率s
        stdin, stdout, stderr = ssh.exec_command("top -b -n 1")
        lines = stdout.readlines()
        gaussdb_line = None
        for line in lines:
            if 'gaussdb' in line:
                gaussdb_line = line
                break
        if gaussdb_line:
            columes = gaussdb_line.split()
            cpu_usage = columes[8]
            state_list.append(cpu_usage)
            mem_usage = columes[9]
            state_list.append(mem_usage)
        else:
            print("gaussdb process not found in top output.")

        # 每秒读取和写入的kB数，kB_rd/s,kB_wr/s
        stdin, stdout, stderr = ssh.exec_command("pidstat -d")
        lines = stdout.readlines()[1:]
        gaussdb_line = None
        for line in lines:
            if 'gaussdb' in line:
                gaussdb_line = line
                break
        if gaussdb_line:
            columes = gaussdb_line.split()
            kB_rd = columes[3]
            state_list.append(kB_rd)
            kB_wr = columes[4]
            state_list.append(kB_wr)
        else:
            print("gaussdb process not found in pidstat")

        # cache_hit_rate
        cache_hit_rate_sql = "select blks_hit / (blks_read + blks_hit + 0.001) " \
                             "from pg_stat_database " \
                             "where datname = '{}';".format(self.database)

        # 并发用户数量
        concurrent_users = """
        SELECT
            count(DISTINCT usename)
        AS
            concurrent_users
        FROM
            pg_stat_activity
        WHERE
            state = 'active';
        """

        # 锁等待次数
        lock = """
        SELECT
            count(*) AS lock_wait_count
        FROM
            pg_stat_activity
        WHERE
            waiting = true;
        """

        # 错误率
        error_rate = """
        SELECT
            (sum(xact_rollback) + sum(conflicts) + sum(deadlocks)) / (sum(xact_commit) + sum(xact_rollback) + sum(conflicts) + sum(deadlocks)) AS error_rate
        FROM
            pg_stat_database;
        """

        # 逻辑读/秒和物理读/秒
        read = """
        SELECT
            logical_reads / (extract(epoch from now() - stats_reset)) AS logical_reads_per_second,
            physical_reads / (extract(epoch from now() - stats_reset)) AS physical_reads_per_second
        FROM (
            SELECT
                sum(tup_returned + tup_fetched) AS logical_reads,
                sum(blks_read) AS physical_reads,
                max(stats_reset) AS stats_reset
            FROM
                pg_stat_database
            ) subquery;
        """

        # 活跃会话数量
        active_session = """
        SELECT
            count(*) AS active_session
        FROM
            pg_stat_activity;
        """

        # 每秒提交的事务数
        transactions_per_second = """
        SELECT
            total_commits / (extract(epoch from now() - max_stats_reset)) AS transactions_per_second
        FROM (
            SELECT
            sum(xact_commit) AS total_commits,
            max(stats_reset) AS max_stats_reset
        FROM
            pg_stat_database
            ) subquery;
        """

        # 扫描行、更新行和删除行
        tup = """
        SELECT
            rows_scanned / (extract(epoch from now() - max_stats_reset)) AS rows_scanned_per_second,
            rows_updated / (extract(epoch from now() - max_stats_reset)) AS rows_updated_per_second,
             rows_deleted / (extract(epoch from now() - max_stats_reset)) AS rows_deleted_per_second
        FROM (
            SELECT
            sum(tup_returned) AS rows_scanned,
            sum(tup_updated) AS rows_updated,
            sum(tup_deleted) AS rows_deleted,
            max(stats_reset) AS max_stats_reset
            FROM
             pg_stat_database
            ) subquery;
        """

        try:
            cursor.execute(cache_hit_rate_sql)
            result = cursor.fetchall()
            for s in result:
                state_list.append(float(s[0]))

            # 并发用户数量
            cursor.execute(concurrent_users)
            result = cursor.fetchall()
            state_list.append(float(result[0][0]))

            # 锁等待次数
            cursor.execute(lock)
            result = cursor.fetchall()
            state_list.append(float(result[0][0]))

            # 错误率
            cursor.execute(error_rate)
            result = cursor.fetchall()
            state_list.append(float(result[0][0]))

            # 逻辑读和物理读
            cursor.execute(read)
            result = cursor.fetchall()
            # print(result)
            for i in result[0]:
                state_list.append(float(i))

            # 活跃会话数
            cursor.execute(active_session)
            result = cursor.fetchall()
            # print(result)
            state_list.append(float(result[0][0]))

            # 每秒提交的事务
            cursor.execute(transactions_per_second)
            result = cursor.fetchall()
            # print(result)
            state_list.append(float(result[0][0]))

            # 扫描、更新、删除行
            cursor.execute(tup)
            result = cursor.fetchall()
            for i in result[0]:
                state_list.append(float(i))

            cursor.close()
            conn.close()
        except Exception as error:
            print(error)
        for i in range(len(state_list)):
            state_list[i] = float(state_list[i])
        return state_list

    # 修改配置参数
    def change_knob(self, knobs):
        ssh = self.get_ssh()
        shell = self.get_shell(ssh)

        print('修改配置参数...', knobs)
        for knob in knobs:
            # 在线调优仅修改经过筛选的参数(无需重启, 重要的)
            if knob not in self.knobs:
                continue

            # integer
            if self.knobs[knob]['vartype'] == 'integer' or self.knobs[knob]['vartype'] == 'int64':
                val = int(knobs[knob])
            # real
            elif self.knobs[knob]['vartype'] == 'real':
                val = float(knobs[knob])
            # string, bool, enum
            else:
                val = knobs[knob]

            if config.online:
                cmd = 'gs_guc reload -Z datanode -N all -I all -c "{}={}" \n'.format(knob, val)
                shell.send(cmd)
                
            else:
                cmd = 'gs_guc set -Z datanode -N all -I all -c "{}={}" \n'.format(knob, val)
                shell.send(cmd)
                
            output = shell.recv(2000)
            info = output.decode('utf-8')
            self.logger.info(f"gs_guc : {info}")
            if info.find("Success") == -1:
                self.logger.info(info)

        # 离线调优重启数据库, 若失败则还原postgresql.conf
        flag_change_knob_success = False
        if not config.online:
            t = threading.Thread(target=self.restart)
            t.setDaemon(True)
            t.start()
            # 在time_wait时间内若重启失败, 则认为由于配置参数取值不合理导致数据库故障, 故恢复重置
            t.join(timeout=config.time_wait+10)
            if not self.restart_flag:
                self.restore()
                print('restore database config')
            else:
                flag_change_knob_success = True
        else:
            flag_change_knob_success = True

        #print("restore database config: ",flag_change_knob_success)

        return flag_change_knob_success

        # return self.restart_flag




if __name__ == '__main__':
    db = Database()
    dn_port = config.dist_dn_port
    conn = db.get_conn(dn_port)
    cursor = conn.cursor()
    sql = "select 1"
    cursor.execute(sql)
    result = cursor.fetchall()
    for s in result:
        print(s[0])

    cursor.close()
    conn.close()

