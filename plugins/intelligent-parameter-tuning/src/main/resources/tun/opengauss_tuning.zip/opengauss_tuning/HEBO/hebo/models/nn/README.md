# README

This module contains several neural network surrogate models, they are basically variants of deep ensemble model.

For Bayesian optimization, neural network based surrogate models are generally outperformed by GP models, however, they can be useful for some specific applications.
