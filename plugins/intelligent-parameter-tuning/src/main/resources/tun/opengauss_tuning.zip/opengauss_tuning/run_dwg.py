import argparse

import config
from SuperWG.DWG.PressureTest.multi_thread_test_only_run_workloads_without_create_schema import \
    multi_thread_without_create_schema

parser = argparse.ArgumentParser()
parser.add_argument('--database_name', type=str, default=config.db)
parser.add_argument('--user_name', type=str, default=config.user)
parser.add_argument('--password', type=str, default=config.password)
parser.add_argument('--host', type=str, default=config.host)
parser.add_argument('--port', type=int, default=config.port)
parser.add_argument('--n_jobs', type=int, default=config.threads)
parser.add_argument('--workload_path', default=config.workload)
parser.add_argument('--id', default=00000)
args = parser.parse_args()

mh = multi_thread_without_create_schema(args)
mh.data_pre()

qps = mh.run()

print('qps = {}'.format(qps))
