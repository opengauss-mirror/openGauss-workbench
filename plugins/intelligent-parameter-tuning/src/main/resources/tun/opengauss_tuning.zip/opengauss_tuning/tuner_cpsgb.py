
import os
import utils
import config
import numpy as np
import pandas as pd
import sys
from pathlib import Path
import time
import json
import joblib
from stress_testing_tool import stress_testing_tool
from smac.facade.conformal_ensemble_facade import ConformalEnsembleFacade
from smac.facade.ensemble_facade import EnsembleFacade
from smac.main.concurrent_optimize import concurrent_optimize

from ConfigSpace import (
    Categorical,
    Configuration,
    ConfigurationSpace,
    #   EqualsCondition,
    #   Float,
    Integer,
)

from smac import Scenario
from smac.initial_design.sobol_design import SobolInitialDesign
from smac.initial_design.custom_design import CustomInitialDesign
from smac.intensifier.intensifier import Intensifier


def get_init_sample_df(init_runhistory_dir):
    init_runhistory_file = Path(init_runhistory_dir, 'runhistory.json')
    with open(init_runhistory_file, 'r') as file:
        init_runhistory = json.load(file)
    init_X = pd.DataFrame([elem for key, elem in init_runhistory['configs'].items()])
    init_y = np.array([elem[4] for elem in init_runhistory['data']]).reshape(-1, 1)
    init_walltime = np.array([elem[5] for elem in init_runhistory['data']]).reshape(-1, 1)
    return init_X, init_y, init_walltime

class TargetWrapper:
    def __init__(self, init_X, init_y):
        init_X_dict = init_X.to_dict(orient='index')
        self.lookup = {tuple(sorted(init_X_dict[index].items())): init_y[index, 0] for index in range(len(init_y))}.copy()

    def wrap(self, target_func):
        def wrapped_target_func(config: Configuration, seed: int = 0):
            config_dict = tuple(sorted(dict(config.items()).items()))
            res = self.lookup.get(config_dict)
            if res is None:
                return target_func(config, seed)
            else:
                print('Use values of initial sampled configs:')
                return res

        return wrapped_target_func

class tuner:
    def __init__(self, db, init_seed=0, exp_label='cpsgb_test', use_cache=True):
        self.method = config.method
        self.iteration = config.iteration
        self.database_name = config.db
        self.sampling_number = config.sampling_number
        # 调优所用到的参数配置
        self.knobs_detail = utils.get_knobs_detail(config.knobs_file)
        self.knobs_number = len(self.knobs_detail)
        self.benchmark = config.benchmark
        # 每次调优设置一个时间戳, 调优数据文件均以时间戳命名, 并用于负载映射的键
        self.id = int(time.time())
        self.logger = utils.get_logger('log/tune_log/{}.log'.format(self.id))
        # 实例化压测工具
        self.stt = stress_testing_tool(self.knobs_detail, self.id, db)
        # 生成初始样本的随机种子
        self.init_seed = init_seed
        # experiment label
        self.exp_label = exp_label
        self.use_cache = use_cache
        self.wrapped_target_func = self.target_fun

    def tune(self, seed=0):
        facade_instance = self.init_CPSGB()
        self.run_cpsgb(facade_instance)

    def init_configspace(self) -> ConfigurationSpace:
        # Build Configuration Space which defines all parameters and their ranges.
        cs = ConfigurationSpace()

        # 初始化样本空间
        for name in self.knobs_detail.keys():
            if self.knobs_detail[name]['vartype'] == "integer":
                # if int(self.knobs_detail[name]['max_val']) > sys.maxsize:
                #     lb = int(self.knobs_detail[name]['min_val'] / 1000000)
                #     ub = int(self.knobs_detail[name]['max_val'] / 1000000)
                #     knob = Integer(name, (lb, ub), default=int((ub + lb) / 2))
                # else:
                lb = int(self.knobs_detail[name]['min_val'])
                ub = int(self.knobs_detail[name]['max_val'])
                knob = Integer(name, (lb, ub), default=int((ub + lb) / 2))
            elif self.knobs_detail[name]['vartype'] == "enumvals":
                knob = Categorical(name, self.knobs_detail[name]['enumvals'],
                                   default=str(self.knobs_detail[name]['enumvals'][0]))
            else:
                raise Exception(f'Unsupported knob_type: {self.knobs_detail[name]["vartype"]}')

            cs.add_hyperparameter(knob)

        return cs

    def init_CPSGB(self):
        # init model_configspace
        model_configspace = self.init_configspace()

        # init scenario
        self.logger.info(f'Total iter: {self.iteration + self.sampling_number}, Init iter: {self.sampling_number}')
        output_directory = Path("/data/tuning/opengauss_tuning/smac3_output", self.exp_label)
        scenario_name = 'EPSGB'
        scenario = Scenario(model_configspace, deterministic=True,
                            n_trials=self.iteration + self.sampling_number, walltime_limit=np.inf, seed=self.init_seed,
                            output_directory=output_directory, name=scenario_name,
                            use_default_config=False)

        # check if there is a historic tuning cache
        dir_runhistory = os.path.join("/data/tuning/opengauss_tuning/smac3_output", self.exp_label, 'EPSGB', str(self.init_seed))
        print(dir_runhistory)
        if os.path.exists(dir_runhistory) and self.use_cache:
            self.logger.info('use_cache!')
            init_X, init_y, _ = get_init_sample_df(dir_runhistory)
            target_wrapper = TargetWrapper(init_X, init_y)
            self.wrapped_target_func = target_wrapper.wrap(self.target_fun)

            initial_design = CustomInitialDesign(
                init_X=init_X, scenario=scenario, n_configs=init_X.shape[0],
                max_ratio=1, additional_configs=[]
            )
        else:
            initial_design = SobolInitialDesign(scenario=scenario, n_configs=self.sampling_number, max_ratio=1)

        # init surrogate model
        # Facade = ConformalEnsembleFacade
        # conformal_strategy = 'j+rcv'
        Facade = EnsembleFacade
        conformal_strategy = 'ensemble'
        hyper_param_tune_dict = {
            'max_depth': [7, 5, 3],
            'num_leaves': [15, 31],
            'learning_rate': [0.01, 0.05],
        }
        hyper_param_tune_mode = 10
        practical_prediction_coverage = False
        conformal_hetero = 'multi'
        selective_strategy = 'minwis_cem'
        cem_opts = {'maxits': 7, 'N': 50, 'Ne': 8}
        conformal_fold = 10
        cv_repeats = 5
        scipy_maxiter = 300

        use_pred_R2 = True
        train_failure_rate = 0.9
        acquisition_maximizer = Facade.get_acquisition_maximizer(scenario,
                                                                 scipy_maxiter=scipy_maxiter,
                                                                 lhs_last_index=self.sampling_number,
                                                                 scipy_parallel_thread=8)

        model_tuner = Facade.get_model(scenario,
                                       early_stopping_rounds=50,
                                       num_boost_round=500,
                                       max_depth=7,
                                       learning_rate=0.05,
                                       feature_fraction=1,
                                       num_leaves=15,
                                       max_bin=127,
                                       conformal_alphas=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
                                       conformal_strategy=conformal_strategy,
                                       conformal_hetero=conformal_hetero,
                                       selective_strategy=selective_strategy,
                                       cem_opts=cem_opts,
                                       conformal_fold=conformal_fold,
                                       cv_repeats=cv_repeats,
                                       hyper_param_tune_mode=hyper_param_tune_mode,
                                       hyper_param_tune_dict=hyper_param_tune_dict,
                                       trim_train_iter=3,
                                       train_failure_rate=train_failure_rate,
                                       use_pred_R2=use_pred_R2,
                                       n_jobs=16,
                                       base_num_threads=1,
                                       practical_prediction_coverage=practical_prediction_coverage)


        # init final facade
        intensifier = Intensifier(scenario=scenario, max_config_calls=1)
        config_selector = Facade.get_config_selector(scenario, retrain_after=1)
        facade_instance = Facade(scenario, self.wrapped_target_func, model=model_tuner,
                                 intensifier=intensifier, initial_design=initial_design,
                                 config_selector=config_selector,
                                 acquisition_maximizer=acquisition_maximizer,
                                 overwrite=True)

        return facade_instance


    def run_cpsgb(self, facade_instance):
        def post_step_fun(step, config, cost):
            qps = -cost
            temp_config = dict(config.items())
            self.logger.info(
                str(self.id) + '\tsuggest ' + str(step + 1) + '\t' + str(temp_config) + "\tqps = " + str(qps) + '\n')
            print('suggest {}: qps = {}'.format(step + 1, qps))

        t0 = time.time()
        # incumbent = tuner.optimize()
        concurrent_optimize(self.sampling_number + self.iteration, self.sampling_number,
                            self.wrapped_target_func, facade_instance,
                            pre_target_func=self.stt.db.restore_backup_data,
                            activate_pre_target_after_init=False,
                            verbose=True, post_step_fun=post_step_fun)
        runhistory = []
        trajectory = []
        min_step = 0
        incumbent_cost = 10000
        incumbent = None
        for step, (key, value) in enumerate(facade_instance.runhistory.items()):
            step_result = {'step': step + 1,
                           'cost': value.cost,
                           'walltime': value.time,
                           'config': dict(facade_instance.runhistory.get_config(key.config_id))}
            if step_result['cost'] < incumbent_cost:
                min_step = step_result['step']
                incumbent_cost = step_result['cost']
                incumbent = step_result['config']
                trajectory.append(step_result)
            runhistory.append(step_result)
        best_result = {'trial': min_step, 'cost': incumbent_cost, 'config': incumbent}

        # record
        print(f'incumbent_cpsgb: {incumbent}')
        print(f"cost_cpsgb: {incumbent_cost}")
        timing_method = round(time.time() - t0, 3)
        print(f'CPSGB Timing: {timing_method}')

        # save experiment result for a tuning method
        joblib.dump(trajectory, f'yuanhao/cpsgb_result/trajectories_cpsgb.joblib')
        joblib.dump(runhistory, f'yuanhao/cpsgb_result/runhistories__cpsgb.joblib')
        joblib.dump(best_result, f'yuanhao/cpsgb_result/best_results_cpsgb.joblib')
        joblib.dump(timing_method, f'yuanhao/cpsgb_result/timing_cpsgb.joblib')



    def target_fun(self, knobs: Configuration, seed: int = 0):
        # preprocess new knob
        knobs_dict = dict(knobs.items())
        rec_x = pd.DataFrame([knobs_dict])
        qps = self.stt.handle_CPSGB_config(rec_x, seed=seed, enable_restore_data=False)
        return -qps
