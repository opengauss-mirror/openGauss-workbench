#!/usr/bin/env bash

#elasticsearch host:port
eshost=$1
#node ID: nodeid
nodeid=$2
#opengauss log path(default:/data/opengauss/install/data/datanode1/pg_log):
opengausslog=$3
#opengauss slow log path(default:/data/opengauss/install/data/datanode1/pg_log):
opengaussslowlog=$4
#Please enter opengauss error log path(default:/data/opengauss/install/data/datanode1/pg_log):
opengausserrorlog=$5
gsCtlLogPath=$6
gsGucLogPath=$7
gsOmLogPath=$8
gsInstallLogPath=$9
gsLocalLogPath=$10

echo -------filebeat.yml-----
sed -i 's/119.3.170.242:9200/'${eshost}'/g' filebeat.yml
sed -i 's/ogbrench2/'${nodeid}'/g' filebeat.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/opengauss/log/ingest/pipeline.yml
echo -------manifest.yml path-----
sed -i 's#/data/opengauss/install/data/datanode1/pg_log#'${opengausslog}'#g' module/opengauss/log/manifest.yml
sed -i 's#/data/opengauss/install/data/datanode1/pg_log#'${opengaussslowlog}'#g' module/opengauss/slowlog/manifest.yml
sed -i 's#/data/opengauss/install/data/datanode1/pg_log#'${opengausserrorlog}'#g' module/opengauss/errorlog/manifest.yml
echo -------manifest.yml node-----
sed -i 's/pipeline.yml/pipeline-'${nodeid}'.yml/g' module/opengauss/errorlog/manifest.yml
sed -i 's/pipeline-errorlog.yml/pipeline-errorlog-'${nodeid}'.yml/g' module/opengauss/errorlog/manifest.yml
sed -i 's/pipeline-csv.yml/pipeline-csv-'${nodeid}'.yml/g' module/opengauss/errorlog/manifest.yml
sed -i 's/pipeline.yml/pipeline-'${nodeid}'.yml/g' module/opengauss/log/manifest.yml
sed -i 's/pipeline-log.yml/pipeline-log-'${nodeid}'.yml/g' module/opengauss/log/manifest.yml
sed -i 's/pipeline-csv.yml/pipeline-csv-'${nodeid}'.yml/g' module/opengauss/log/manifest.yml
sed -i 's/pipeline.yml/pipeline-'${nodeid}'.yml/g' module/opengauss/slowlog/manifest.yml
sed -i 's/pipeline-slowlog.yml/pipeline-slowlog-'${nodeid}'.yml/g' module/opengauss/slowlog/manifest.yml
sed -i 's/pipeline-csv.yml/pipeline-csv-'${nodeid}'.yml/g' module/opengauss/slowlog/manifest.yml
echo -------manifest.yml node-----
sed -i 's/pipeline.yml/pipeline-'${nodeid}'.yml/g' module/system/errorlog/manifest.yml
sed -i 's/pipeline.yml/pipeline-'${nodeid}'.yml/g' module/system/syslog/manifest.yml
echo -------pipeline.yml----------
sed -i 's/pipeline-errorlog/pipeline-errorlog-'${nodeid}'/g' module/opengauss/errorlog/ingest/pipeline.yml
sed -i 's/pipeline-csv/pipeline-csv-'${nodeid}'/g' module/opengauss/errorlog/ingest/pipeline.yml
sed -i 's/pipeline-log/pipeline-log-'${nodeid}'/g' module/opengauss/log/ingest/pipeline.yml
sed -i 's/pipeline-csv/pipeline-csv-'${nodeid}'/g' module/opengauss/log/ingest/pipeline.yml
sed -i 's/pipeline-slowlog/pipeline-slowlog-'${nodeid}'/g' module/opengauss/slowlog/ingest/pipeline.yml
sed -i 's/pipeline-csv/pipeline-csv-'${nodeid}'/g' module/opengauss/slowlog/ingest/pipeline.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/opengauss/errorlog/ingest/pipeline.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/opengauss/errorlog/ingest/pipeline.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/opengauss/log/ingest/pipeline.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/opengauss/log/ingest/pipeline.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/opengauss/slowlog/ingest/pipeline.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/system/errorlog/ingest/pipeline.yml
sed -i 's/ogbrench2/'${nodeid}'/g' module/system/syslog/ingest/pipeline.yml
echo -------pipeline-nodeid-------
mv module/opengauss/errorlog/ingest/pipeline.yml module/opengauss/errorlog/ingest/pipeline-${nodeid}.yml
mv module/opengauss/errorlog/ingest/pipeline-csv.yml module/opengauss/errorlog/ingest/pipeline-csv-${nodeid}.yml
mv module/opengauss/errorlog/ingest/pipeline-errorlog.yml module/opengauss/errorlog/ingest/pipeline-errorlog-${nodeid}.yml
mv module/opengauss/log/ingest/pipeline.yml module/opengauss/log/ingest/pipeline-${nodeid}.yml
mv module/opengauss/log/ingest/pipeline-csv.yml module/opengauss/log/ingest/pipeline-csv-${nodeid}.yml
mv module/opengauss/log/ingest/pipeline-log.yml module/opengauss/log/ingest/pipeline-log-${nodeid}.yml
mv module/opengauss/slowlog/ingest/pipeline.yml module/opengauss/slowlog/ingest/pipeline-${nodeid}.yml
mv module/opengauss/slowlog/ingest/pipeline-csv.yml module/opengauss/slowlog/ingest/pipeline-csv-${nodeid}.yml
mv module/opengauss/slowlog/ingest/pipeline-slowlog.yml module/opengauss/slowlog/ingest/pipeline-slowlog-${nodeid}.yml
mv module/system/errorlog/ingest/pipeline.yml module/system/errorlog/ingest/pipeline-${nodeid}.yml
mv module/system/syslog/ingest/pipeline.yml module/system/syslog/ingest/pipeline-${nodeid}.yml